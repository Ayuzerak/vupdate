import xbmc
import xbmcvfs
import shutil
import os
import time
import urllib.request

def download_file(url, dest_path):
    try:
        with urllib.request.urlopen(url) as response, open(dest_path, 'wb') as out_file:
            out_file.write(response.read())
        return True
    except Exception as e:
        VSlog(f"Failed to download file: {e}")
        return False

def isMatrix():
    try:
        version = xbmc.getInfoLabel('system.buildversion')
        if version[0:2] >= '19':
            return True
        else:
            return False
    except:
        return False

    # Transforme les "special" en chemin normal.
def VSPath(pathSpecial):
    if isMatrix():
        path = xbmcvfs.translatePath(pathSpecial)
    else:
        path = xbmc.translatePath(pathSpecial)
    return path

# Log messages to Kodi's log system
def VSlog(message):
    xbmc.log(f"[vStream Update]: {message}", level=xbmc.LOGINFO)

# Define paths for updates
src_path = VSPath('special://home/addons/plugin.video.vstream/').replace('\\', '/')

src_update_file = os.path.join(src_path, 'resources', 'lib', 'update.py').replace('\\', '/')

src_update_folder = os.path.dirname(src_update_file)

# Define the update file URL and destination path
sUrl = "https://raw.githubusercontent.com/Ayuzerak/vupdate/refs/heads/main/update.py"
vstreamupdate_path = VSPath('special://home/addons/service.vstreamupdate/').replace('\\', '/')

# Save the downloaded file to the destination
new_update_file = os.path.join(vstreamupdate_path, "update.py").replace('\\', '/')
if download_file(sUrl, new_update_file):
    VSlog(f"File saved successfully to {new_update_file}")
else:
    VSlog(f"Failed to save file to {new_update_file}")

# Copy the new update.py file
if os.path.isfile(new_update_file):
    try:
        shutil.copy(new_update_file, src_update_file)
        VSlog(f"Copied new update.py file from {vstreamupdate_path} to {src_update_folder}")
    except Exception as e:
        VSlog(f"Failed to copy new update.py: {e}")


