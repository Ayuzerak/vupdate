import os
import shutil
import time
import hashlib
import re
import threading
import urllib.request
import xbmc
import xbmcvfs
from typing import Optional

from vstream import VStream  # Reintroduced per request
from resources.lib.logger import VSPath, VSlog


def insert_hash_as_comment(file_hash: str, file_path: str) -> None:
    """
    Insert the given hash as a comment into the file immediately after any initial comment block,
    but only if the correct hash comment is not already present anywhere in the file.

    The hash comment is in the format:
        # Hash: {file_hash}

    An "initial comment block" is defined as the contiguous group of lines at the beginning of the file 
    that are either blank or start with '#'.

    :param file_hash: The hash string to insert.
    :param file_path: The path of the file to update.
    """
    expected_comment = f"# Hash: {file_hash}"
    
    # Read the file contents using xbmcvfs.File in binary mode.
    try:
        with xbmcvfs.File(file_path, "rb") as f:
            raw_content = f.read()
        # Decode the file content using UTF-8.
        content = raw_content.decode("utf-8", errors="ignore")
        # Split lines while preserving line endings.
        lines = content.splitlines(keepends=True)
    except Exception as e:
        raise FileNotFoundError(f"File not found: {file_path}. Error: {e}")

    # Check if the expected hash comment is already present.
    if any(line.strip() == expected_comment for line in lines):
        VSlog(f"[INFO] Hash comment is already present in {file_path}")
        return

    # Determine the insertion point: after any initial comment block.
    insertion_index = 0
    for line in lines:
        stripped_line = line.strip()
        if stripped_line == "" or stripped_line.startswith("#"):
            insertion_index += 1
        else:
            break

    # Prepare the comment line with a newline and insert it.
    comment_line = expected_comment + "\n"
    lines.insert(insertion_index, comment_line)

    # Write the updated content back to the file in binary mode.
    new_content = "".join(lines)
    with xbmcvfs.File(file_path, "wb") as f:
        f.write(new_content.encode("utf-8"))
    VSlog(f"[INFO] Hash comment inserted in: {file_path}")


def compute_file_hash(file_path: str) -> Optional[str]:
    """
    Compute the SHA256 hash of a file.

    :param file_path: The path of the file to hash.
    :return: The hexadecimal SHA256 hash, or None if an error occurs.
    """
    VSlog(f"[INFO] Starting hash computation for file: {file_path}")
    try:
        sha256 = hashlib.sha256()
        with xbmcvfs.File(file_path, 'rb') as f:
            while True:
                chunk = f.read(4096)  # Read in 4KB chunks
                if not chunk:
                    break
                sha256.update(chunk)
        hash_result = sha256.hexdigest()
        VSlog(f"[INFO] Hash computed successfully for file {file_path}: {hash_result}")
        return hash_result
    except Exception as e:
        VSlog(f"[ERROR] Failed to compute hash for file {file_path}. Error: {e}")
        return None


def file_has_hash(file_path: str, expected_hash: str) -> bool:
    """
    Check if the file contains the expected hash comment anywhere in its content.

    :param file_path: The path to the file.
    :param expected_hash: The hash value expected in the comment.
    :return: True if any comment line contains the expected hash; False otherwise.
    """
    try:
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read()
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='ignore')
        for line in content.splitlines():
            stripped_line = line.strip()
            if stripped_line.startswith('#') and f'Hash: {expected_hash}' in stripped_line:
                VSlog(f"[INFO] File {file_path} contains hash: {expected_hash}")
                return True
        return False
    except Exception as e:
        VSlog(f"[ERROR] Failed to check hash in {file_path}: {e}")
        return False


def download_file(url: str, dest_path: str, retries: int = 3, delay: int = 5) -> bool:
    """
    Download a file from a URL with a number of retries.

    :param url: The URL to download.
    :param dest_path: The local file path to save the file.
    :param retries: The number of download attempts.
    :param delay: Delay in seconds between attempts.
    :return: True if the file was downloaded successfully; False otherwise.
    """
    for attempt in range(1, retries + 1):
        try:
            # If the destination file exists, compare its size to the remote file's size.
            if xbmcvfs.exists(dest_path):
                req = urllib.request.Request(url, method='HEAD')
                with urllib.request.urlopen(req) as response:
                    remote_size = response.getheader('Content-Length')
                with xbmcvfs.File(dest_path, 'rb') as f:
                    local_size = f.size()
                if remote_size and int(remote_size) == local_size:
                    VSlog("[INFO] File already downloaded and up to date. Skipping download.")
                    return False

            with urllib.request.urlopen(url) as response:
                data = response.read()
            with xbmcvfs.File(dest_path, 'wb') as f:
                f.write(data)
            VSlog(f"[INFO] Successfully downloaded {url} to {dest_path}")
            return True
        except Exception as e:
            VSlog(f"[WARNING] Download attempt {attempt} failed: {e}")
            time.sleep(delay)
    VSlog(f"[ERROR] Failed to download {url} after {retries} attempts.")
    return False


def update_by_vstream(file_path: str) -> bool:
    """
    Check whether the update file is marked for vstream usage by scanning for a marker.

    :param file_path: The path to the update file.
    :return: True if the file is marked for vstream usage; False otherwise.
    """
    marker_regex = re.compile(r'#\s*update\s+by\s+vstream', re.IGNORECASE)
    
    try:
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read()
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='ignore')
        for line in content.splitlines():
            if marker_regex.search(line):
                return True
        return False
    except Exception as e:
        VSlog(f"[ERROR] Failed to read file {file_path} for update check: {e}")
        return False


def perform_vstream_update(new_update_file: str, installed_update_file: str, is_vstream_update: bool) -> None:
    """
    Perform the update routine for vstream.

    Depending on the update marker, this function either simply copies the new update file
    or reloads the update module and executes its update setting.

    :param new_update_file: The path to the newly downloaded update file.
    :param installed_update_file: The path to the currently installed update file.
    :param is_vstream_update: Boolean flag indicating whether the update is for vstream usage.
    """
    VSlog(f"[INFO] vstream_update called at {time.strftime('%Y-%m-%d %H:%M:%S')}")
    try:
        if is_vstream_update:
            VSlog("[INFO] update.py is marked for vstream usage.")
            shutil.copy(new_update_file, installed_update_file)
            VSlog(f"[INFO] update.py copied successfully to {installed_update_file}.")
        else:
            VSlog("[INFO] update.py is not marked for vstream usage; proceeding with src update.")
            shutil.copy(new_update_file, installed_update_file)
            VSlog(f"[INFO] Copied new update.py from {new_update_file} to {installed_update_file}.")
            # Reload the module to ensure the new code is used.
            from importlib import reload
            from resources.lib import update
            reload(update)
            from resources.lib.update import cUpdate
            update_instance = cUpdate()
            update_instance.getUpdateSetting()
            VSlog("[INFO] Executed cUpdate().getUpdateSetting() successfully.")
            new_hash = compute_file_hash(new_update_file)
            if new_hash:
                insert_hash_as_comment(new_hash, installed_update_file)
            else:
                VSlog("[ERROR] Failed to compute hash for new update file; hash comment not inserted.")
    except Exception as e:
        VSlog(f"[ERROR] vstream update failed: {e}")


def execute_update_setting(download_update_file: str, vstream_update_file: str, src_update_file: str) -> None:
    """
    Execute the update routine by determining the correct target update file based on the marker in the downloaded update file.

    :param download_update_file: The path to the newly downloaded update file.
    :param vstream_update_file: The target update file path for vstream usage.
    :param src_update_file: The target update file path for src usage.
    """
    try:
        is_vstream_update = update_by_vstream(download_update_file)
        if is_vstream_update:
            VSlog("[INFO] New update file is marked for vstream; using vstream_update_file as target.")
            perform_vstream_update(download_update_file, vstream_update_file, is_vstream_update)
        else:
            VSlog("[INFO] New update file is not marked for vstream; using src_update_file as target.")
            perform_vstream_update(download_update_file, src_update_file, is_vstream_update)
    except Exception as e:
        VSlog(f"[ERROR] Failed to execute update function: {e}")


def is_installed(new_file: str, flag_file: str) -> bool:
    """
    Determine whether the installed update file already includes the hash of the new update file.

    :param new_file: The path to the newly downloaded update file.
    :param flag_file: The path to the installed update file to check for the hash comment.
    :return: True if the installed file starts with the correct hash comment; False otherwise.
    """
    new_hash = compute_file_hash(new_file)
    if new_hash is None:
        return False
    return file_has_hash(flag_file, new_hash)


def periodic_update(download_update_file: str, vstream_update_file: str, src_update_file: str, interval: int) -> None:
    """
    Periodically check and execute the update routine.

    :param download_update_file: The path to the downloaded update file.
    :param vstream_update_file: The target update file path for vstream usage.
    :param src_update_file: The target update file path for src usage.
    :param interval: The interval (in seconds) between update checks.
    """
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if not is_installed(download_update_file, vstream_update_file):
            try:
                execute_update_setting(download_update_file, vstream_update_file, src_update_file)
            except Exception as e:
                VSlog(f"[ERROR] Periodic update check failed: {e}")
        if monitor.waitForAbort(interval):
            break
    VSlog("[INFO] Update monitor thread terminated.")


# Define paths for update files.
vstreamupdate_path = VSPath('special://home/addons/service.vstreamupdate/').replace('\\', '/')
src_update_file = os.path.join(vstreamupdate_path, 'resources', 'lib', 'update.py').replace('\\', '/')
download_update_file = os.path.join(vstreamupdate_path, "update.py").replace('\\', '/')
vstream_update_file = VSPath('special://home/addons/plugin.video.vstream/resources/lib/update.py').replace('\\', '/')

# URL of the new update file.
update_url = "https://raw.githubusercontent.com/Ayuzerak/vupdate/refs/heads/main/update.py"

# Download the update file and execute the update if the download was successful.
if download_file(update_url, download_update_file):
    VSlog(f"[INFO] File saved successfully to {download_update_file}")
    execute_update_setting(download_update_file, vstream_update_file, src_update_file)

# Start the periodic update check in a separate daemon thread.
periodic_thread = threading.Thread(
    target=periodic_update,
    args=(download_update_file, vstream_update_file, src_update_file, 60),
    daemon=True
)

periodic_thread.start()
