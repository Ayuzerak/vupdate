import os
import xml.etree.ElementTree as ET
import traceback
from xml.dom import minidom
from resources.lib.logger import VSPath, VSlog

class Bootstrap:
    def __init__(self):
        VSlog("Bootstrap::__init__ called.")

    def init(self):
        VSlog("Bootstrap::init called.")
        addon_xml_path = VSPath("special://home/addons/plugin.video.vstream/addon.xml").replace('\\', '/')
        self.insert_import_lines(addon_xml_path, ["script.module.regex", "script.module.astor"])

    def insert_import_lines(self, addon_xml_path, import_addons, marker_import="script.module.dnspython"):
        """
        Ensures that addon.xml contains import lines for the specified addons.
        Inserts new <import> elements before the marker import (if found) or appends them otherwise.
        After writing the file, verifies that the new imports are present.
        """
        VSlog("Bootstrap::insert_import_lines() called.")
        try:
            # Check if the file exists
            if not os.path.exists(addon_xml_path):
                VSlog(f"Error: File not found - {addon_xml_path}")
                return

            # Parse the XML file
            tree = ET.parse(addon_xml_path)
            root = tree.getroot()

            # Locate the <requires> element
            requires = root.find("requires")
            if requires is None:
                VSlog("No <requires> element found in addon.xml.")
                return

            # Build a set of existing imports from direct child <import> elements.
            existing_imports = {imp.get("addon") for imp in requires.findall("import") if imp.get("addon")}

            # Prepare new import elements for addons that are not already imported.
            new_import_elements = []
            for addon in import_addons:
                if addon in existing_imports:
                    VSlog(f"Import '{addon}' already exists in addon.xml; skipping.")
                else:
                    new_imp = ET.Element("import")
                    new_imp.set("addon", addon)
                    new_import_elements.append(new_imp)
                    VSlog(f"Prepared to add import '{addon}'.")

            if not new_import_elements:
                VSlog("No new imports to add.")
                return

            # Locate the marker import element in <requires> to determine the insertion point.
            marker_index = None
            for idx, child in enumerate(list(requires)):
                if child.tag == "import" and child.get("addon") == marker_import:
                    marker_index = idx
                    break

            # Insert new import elements before the marker if found, otherwise append them.
            if marker_index is not None:
                for i, new_imp in enumerate(new_import_elements):
                    requires.insert(marker_index + i, new_imp)
                VSlog(f"Inserted {len(new_import_elements)} import(s) before marker import '{marker_import}'.")
            else:
                for new_imp in new_import_elements:
                    requires.append(new_imp)
                VSlog(f"Appended {len(new_import_elements)} import(s) to the <requires> element.")

            # Pretty-print the XML manually using minidom (for compatibility with Python <3.9)
            def prettify(elem):
                rough_string = ET.tostring(elem, 'utf-8')
                reparsed = minidom.parseString(rough_string)
                return reparsed.toprettyxml(indent="    ")

            # Write the modified XML back to the file
            with open(addon_xml_path, "w", encoding="utf-8") as f:
                f.write(prettify(root))

            # Verification: Re-open the file and confirm the new import lines were added.
            tree_ver = ET.parse(addon_xml_path)
            root_ver = tree_ver.getroot()
            requires_ver = root_ver.find("requires")
            updated_imports = {imp.get("addon") for imp in requires_ver.findall("import") if imp.get("addon")}
            missing = [addon for addon in import_addons if addon not in updated_imports]

            if missing:
                VSlog(f"Warning: The following imports were not added: {missing}")
            else:
                VSlog("Successfully modified addon.xml with the new import lines.")

        except Exception as e:
            VSlog(f"Error modifying addon.xml: {traceback.format_exc()}")
