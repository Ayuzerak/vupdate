import re
# Import custom logger and path helper from the addon's resources.
from resources.lib.logger import VSPath, VSlog

class Bootstrap:
    def init(self):
        VSlog("Bootstrap::init called.")
        addon_xml_path = VSPath("special://home/addons/plugin.video.vstream/resources/addon.xml")
        self.insert_regex_import_line(addon_xml_path)

    def insert_regex_import_line(self, addon_xml_path):
        """
        Ensures that the addon.xml file contains the line:
            <import addon="script.module.regex"/>
        If missing, it inserts this line before the
        <import addon="script.module.dnspython" optional="true"/> line if it exists,
        or before the closing </requires> tag otherwise.
        
        Args:
            addon_xml_path (str): The path to the addon.xml file.
        """
        VSlog("Bootstrap::insert_regex_import_line() called.")

        try:
            with open(addon_xml_path, 'r', encoding='utf-8') as file:
                content = file.read()

            # Check if the regex import line already exists.
            if re.search(r'<import\s+addon="script\.module\.regex"', content):
                print("The regex import line is already present in the file.")
                return

            # The line to be inserted (maintain proper indentation as in the XML).
            regex_import_line = '        <import addon="script.module.regex"/>\n'
            
            # Try to find the dnspython import line to insert before it.
            dnspython_pattern = r'(^\s*<import\s+addon="script\.module\.dnspython".*>)'
            dnspython_match = re.search(dnspython_pattern, content, re.MULTILINE)
            if dnspython_match:
                insertion_point = dnspython_match.start()
                new_content = content[:insertion_point] + regex_import_line + content[insertion_point:]
            else:
                # If dnspython import isn't found, insert before the closing </requires> tag.
                requires_close_pattern = r'(^\s*</requires>)'
                requires_close_match = re.search(requires_close_pattern, content, re.MULTILINE)
                if requires_close_match:
                    insertion_point = requires_close_match.start()
                    new_content = content[:insertion_point] + regex_import_line + content[insertion_point:]
                else:
                    # Fallback: append the import line at the end.
                    new_content = content + "\n" + regex_import_line

            # Write the modified content back to the file.
            with open(addon_xml_path, 'w', encoding='utf-8') as file:
                file.write(new_content)
            
            print("Inserted the regex import line into addon.xml.")
        
        except Exception as e:
            print(f"An error occurred while modifying the file: {e}")

