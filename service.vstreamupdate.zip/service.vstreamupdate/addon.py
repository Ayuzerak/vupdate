import os                # For operating system path and file operations
import shutil            # For file operations (if needed; here we use xbmcvfs mostly)
import time              # For delays, time stamps, and periodic checks
import hashlib           # For computing SHA-256 file hashes
import re                # For regular expression matching
import threading         # To run periodic update checks in a background thread
import urllib.request    # To download update files from a remote URL
import xbmc              # Kodi’s xbmc module (used for monitoring Kodi’s abort signal)
import xbmcvfs           # Kodi’s virtual file system module for file I/O operations
from email.utils import parsedate_to_datetime
import datetime  # For timezone handling
import resources.lib.utils as utils 
from typing import Optional  # For optional type hints

# Import VStream module (reintroduced per request)
from vstream import VStream
from resources.lib.bootstrap import Bootstrap

# Import custom logger and path helper from the addon's resources.
from resources.lib.logger import VSPath, VSlog

def insert_hash_as_comment(file_hash: str, file_path: str) -> None:
    """
    Inserts or updates a hash comment (e.g., "# Hash: <hash>") at the top of a file.
    The comment is inserted after any leading blank or comment lines. If a hash comment
    is already present but with a different hash, it will be replaced with the new hash.
    
    :param file_hash: The hash value to insert.
    :param file_path: The path to the file that needs the hash comment.
    """
    # Construct the expected hash comment line.
    expected_comment = f"# Hash: {file_hash}"
    try:
        # Open the file for reading using Kodi's xbmcvfs.
        f = xbmcvfs.File(file_path, 'r')                          
        content = f.read()
        f.close()

        # Detect the file's line ending. Default to '\n'.
        line_ending = '\n'
        if content:
            if '\r\n' in content:
                line_ending = '\r\n'
            elif '\r' in content:
                line_ending = '\r'
            else:
                line_ending = '\n'

        # Split the file content into lines.
        # Using splitlines() handles all common line endings.
        lines = content.splitlines()

        # Flag to indicate if we've updated an existing hash comment.
        hash_comment_updated = False

        # Scan through the lines to check for an existing hash comment.
        for i, line in enumerate(lines):
            stripped_line = line.strip()
            # Check if the line looks like a hash comment.
            if stripped_line.startswith("# Hash:"):
                # Use a regex to extract the hash value from the comment.
                match = re.match(r'^#\s*Hash:\s*(.*)$', stripped_line)
                if match:
                    current_hash = match.group(1).strip()
                    if current_hash == file_hash:
                        VSlog(f"Hash comment is already present in {file_path}")
                        return
                    else:
                        # Replace the existing hash comment with the new one.
                        lines[i] = expected_comment
                        VSlog(f"Hash comment updated in {file_path}")
                        hash_comment_updated = True
                        break  # Assuming only one hash comment should exist.

        if not hash_comment_updated:
            # Determine the proper insertion index by skipping initial blank or comment lines.
            insertion_index = 0
            for line in lines:
                stripped_line = line.strip()
                if stripped_line == "" or stripped_line.startswith("#"):
                    insertion_index += 1
                else:
                    break
            # Insert the new hash comment at the computed index.
            lines.insert(insertion_index, expected_comment)
            VSlog(f"Hash comment inserted in {file_path}")

        # Reassemble the file content using the detected line ending.
        new_content = line_ending.join(lines)
        # Preserve a trailing newline if the original content ended with one.
        if content.endswith(('\n', '\r')):
            new_content += line_ending

        # Open the file for writing using xbmcvfs and save the updated content.
        f = xbmcvfs.File(file_path, 'w')
        success = f.write(new_content)
        f.close()

        if not success:
            VSlog(f"Failed to write to {file_path}")

    except Exception as e:
        VSlog(f"Error inserting/updating hash comment in {file_path}: {e}")
        raise

def compute_file_hash(file_path: str) -> Optional[str]:
    """
    Computes the SHA-256 hash of the file located at file_path.
    
    :param file_path: The path of the file to hash.
    :return: The computed hash as a hexadecimal string or None if an error occurs.
    """
    VSlog(f"Starting hash computation for file: {file_path}")
    try:
        # Initialize a new SHA-256 hash object.
        sha256 = hashlib.sha256()

        chunk_size = 4096
        # Open the file in binary mode using xbmcvfs.
        with xbmcvfs.File(file_path, 'rb') as f:
            while True:
                chunk = f.readBytes(chunk_size)
                if not chunk:
                    break
                h.update(chunk)

                # Kodi's xbmcvfs.File might return a Unicode string even in binary mode.
                # If that happens, encode the chunk to bytes.
                if isinstance(chunk, str):
                    chunk = chunk.encode('utf-8')
                sha256.update(chunk)

        # Convert the hash to a hexadecimal string.
        hash_result = sha256.hexdigest()
        VSlog(f"Hash computed successfully for file {file_path}: {hash_result}")
        return hash_result
    except Exception as e:
        # Log the error and return None if hashing fails.
        VSlog(f"Failed to compute hash for file {file_path}. Error: {e}")
        return None

def file_has_hash(file_path: str, expected_hash: str) -> bool:
    """
    Check if the file contains a comment with the expected hash anywhere in its content.
    
    :param file_path: The path to the file.
    :param expected_hash: The hash value to search for in the file's comments.
    :return: True if the expected hash is found in a comment; False otherwise.
    """
    try:
        # Open the file in binary mode.
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read()
            # If content is in bytes, decode it to a string.
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='ignore')
        # Split content into lines and check each line for the hash comment.
        for line in content.splitlines():
            stripped_line = line.strip()
            if stripped_line.startswith('#') and f'Hash: {expected_hash}' in stripped_line:
                VSlog(f"[INFO] File {file_path} contains hash: {expected_hash}")
                return True
        VSlog(f"[INFO] File {file_path} does not contain hash: {expected_hash}")
        return False
    except Exception as e:
        # Log an error if the file could not be read or processed.
        VSlog(f"[ERROR] Failed to check hash in {file_path}: {e}")
        return False

def download_file(url: str, dest_path: str, retries: int = 3, delay: int = 5) -> bool:
    """
    Download a file from a given URL and save it locally.
    The function first attempts to verify the local file using secure hash headers:
      1. X-Checksum-Sha256
      2. X-Checksum-Sha1
      3. Content-MD5
      4. ETag (assumed to be MD5)
    If none of the hash headers is available, it falls back to comparing file size (Content-Length)
    and finally uses Last-Modified timestamps (with explicit UTC handling) as a last resort.

    :param url: The URL of the file to download.
    :param dest_path: The local destination path to save the file.
    :param retries: Number of retry attempts in case of failure.
    :param delay: Delay (in seconds) between retry attempts.
    :return: True if the file was successfully downloaded; False if it was already up to date or the download fails.
    """
    for attempt in range(1, retries + 1):
        try:
            # Check if the file exists locally.
            if xbmcvfs.exists(dest_path):
                req = urllib.request.Request(url, method='HEAD')
                with urllib.request.urlopen(req) as response:
                    headers = response.headers
                    
                    # Attempt to retrieve secure hash headers (in order of priority).
                    remote_hash = None
                    hash_algo = None

                    if headers.get('X-Checksum-Sha256'):
                        remote_hash = headers.get('X-Checksum-Sha256').strip('"')
                        hash_algo = 'sha256'
                    elif headers.get('X-Checksum-Sha1'):
                        remote_hash = headers.get('X-Checksum-Sha1').strip('"')
                        hash_algo = 'sha1'
                    elif headers.get('Content-MD5'):
                        remote_hash = headers.get('Content-MD5').strip('"')
                        hash_algo = 'md5'
                    elif headers.get('ETag'):
                        # Note: ETag isn't always a hash. Here we assume it is MD5 for fallback.
                        remote_hash = headers.get('ETag').strip('"')
                        hash_algo = 'md5'
                    
                    # If a remote hash is provided, compute and compare the local file's hash.
                    if remote_hash and hash_algo:
                        local_hash = compute_file_hash(dest_path, hash_algo)
                        if local_hash == remote_hash:
                            VSlog("[INFO] File already downloaded and up to date (hash matches). Skipping download.")
                            return False

                    # Fallback: check file size if Content-Length is provided.
                    remote_size = headers.get('Content-Length')
                    if remote_size:
                        remote_size = int(remote_size)
                        with xbmcvfs.File(dest_path, 'rb') as f:
                            local_size = f.size()
                        if local_size == remote_size:
                            VSlog("[INFO] File already downloaded and up to date (size matches). Skipping download.")
                            return False

                    # Fallback: check Last-Modified header if available.
                    remote_last_modified = headers.get('Last-Modified')
                    if remote_last_modified:
                        try:
                            remote_dt = parsedate_to_datetime(remote_last_modified)
                            # If the datetime is naive, assume it's in UTC.
                            if remote_dt.tzinfo is None:
                                remote_dt = remote_dt.replace(tzinfo=datetime.timezone.utc)
                            else:
                                # Convert to UTC explicitly.
                                remote_dt = remote_dt.astimezone(datetime.timezone.utc)
                            remote_ts = remote_dt.timestamp()
                            
                            # Get local file modification time. os.path.getmtime returns epoch time in UTC.
                            local_mtime = os.path.getmtime(dest_path)
                            # Allow a small difference (e.g., 1 second) to account for minor discrepancies.
                            if abs(local_mtime - remote_ts) < 1:
                                VSlog("[INFO] File already downloaded and up to date (Last-Modified matches). Skipping download.")
                                return False
                        except Exception as e:
                            VSlog(f"[WARNING] Could not compare Last-Modified header: {e}")

            # Proceed to download the file if none of the checks indicate it's up to date.
            with urllib.request.urlopen(url) as response:
                data = response.read()
            with xbmcvfs.File(dest_path, 'wb') as f:
                f.write(data)
            VSlog(f"[INFO] Successfully downloaded {url} to {dest_path}")
            return True

        except urllib.error.URLError as e:
            VSlog(f"[WARNING] Download attempt {attempt} failed: {e}")
            time.sleep(delay)
        except Exception as e:
            VSlog(f"[ERROR] Unexpected error: {e}")
            break  # Exit early on unexpected errors.

    VSlog(f"[ERROR] Failed to download {url} after {retries} attempts.")
    return False

def update_by_vstream(file_path: str) -> bool:
    """
    Checks whether the downloaded update file is marked for vstream usage.
    This is determined by looking for a marker comment in the file.
    
    :param file_path: The path to the update file.
    :return: True if the marker (e.g., "# update by vstream") is found; False otherwise.
    """
    # Compile a regular expression to look for the marker comment (case-insensitive).
    marker_regex = re.compile(r'#\s*update\s+by\s+vstream', re.IGNORECASE)
    
    try:
        # Open the file in binary mode.
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read()
            # If content is in bytes, decode it to a string.
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='ignore')
        # Check each line to see if it matches the marker regex.
        for line in content.splitlines():
            if marker_regex.search(line):
                return True
        return False
    except Exception as e:
        # Log any error encountered while reading the file.
        VSlog(f"[ERROR] Failed to read file {file_path} for update check: {e}")
        return False

def perform_vstream_update(new_update_file: str, installed_update_file: str, vstream_update_file: str, is_vstream_update: bool) -> None:
    """
    Copies the new update file to the appropriate installed location.
    If the update is not for vstream, additional actions (like module reload and method execution) are performed.
    
    :param new_update_file: The path to the downloaded update file.
    :param installed_update_file: The target path where the update file should be installed.
    :param is_vstream_update: A flag indicating if this is a vstream update.
    """
    VSlog(f'[INFO] vstream_update called at {time.strftime("%Y-%m-%d %H:%M:%S")}')
    try:
        if is_vstream_update:
            VSlog("[INFO] update.py marked for vstream usage.")
            # Copy the new update file to the vstream target location.
            success = xbmcvfs.copy(new_update_file, installed_update_file)
            if not success:
                VSlog(f"[ERROR] Failed to copy {new_update_file} to {installed_update_file}")
                return
            VSlog("[INFO] update.py copied successfully.")
        else:
            VSlog("[INFO] update.py marked for vstreamupdate usage.")
            # Copy the new update file to the src target location.
            success = xbmcvfs.copy(new_update_file, installed_update_file)
            if not success:
                VSlog(f"[ERROR] Failed to copy {new_update_file} to {installed_update_file}")
                return
            VSlog(f"[INFO] Copied new update.py from {new_update_file} to {installed_update_file}")
            
            # Reload the update module to apply new changes.
            from importlib import reload
            from resources.lib import update
            reload(update)
            
            # Create an instance of the update class and execute its update method.
            from resources.lib.update import cUpdate
            update_instance = cUpdate()
            update_instance.getUpdateSetting()
            VSlog("[INFO] Executed cUpdate().getUpdateSetting() successfully.")
            
        # Compute the hash of the new update file.
        new_hash = compute_file_hash(new_update_file)
        if new_hash:
            # Insert the computed hash as a comment into the installed update file.
            insert_hash_as_comment(new_hash, vstream_update_file)
    except Exception as e:
        VSlog(f"[ERROR] vstream update failed: {e}")

def execute_update_setting(download_update_file: str, vstream_update_file: str, src_update_file: str) -> None:
    """
    Determines which update target to use (vstream or src) based on the downloaded update file.
    Then it executes the appropriate update routine.
    
    :param download_update_file: The path to the newly downloaded update file.
    :param vstream_update_file: The target path for vstream usage.
    :param src_update_file: The target path for src usage.
    """
    try:
        bootstrap_instance = Bootstrap()
        bootstrap_instance.init()

        # Check whether the downloaded update file is marked for vstream usage.
        is_vstream_update = update_by_vstream(download_update_file)
        if is_vstream_update:
            VSlog("[INFO] New update file is marked for vstream; using vstream_update_file as target.")
            perform_vstream_update(download_update_file, vstream_update_file, vstream_update_file, is_vstream_update)
        else:
            VSlog("[INFO] New update file is not marked for vstream; using src_update_file as target.")
            perform_vstream_update(download_update_file, src_update_file, vstream_update_file, is_vstream_update)
    except Exception as e:
        VSlog(f"[ERROR] Failed to execute update function: {e}")

def is_installed(new_file: str, flag_file: str) -> bool:
    """
    Determines whether the installed update file already contains the hash of the new update file.
    This helps prevent re-applying the same update.
    
    :param new_file: The path to the newly downloaded update file.
    :param flag_file: The path to the installed update file to check for the hash comment.
    :return: True if the installed file includes the hash; False otherwise.
    """
    new_hash = compute_file_hash(new_file)
    if new_hash is None:
        return False
    return file_has_hash(flag_file, new_hash)

def periodic_update(download_update_file: str, vstream_update_file: str, src_update_file: str, interval: int) -> None:
    """
    Periodically checks for updates and applies them if necessary.
    This function runs in a continuous loop until Kodi sends an abort signal.
    
    :param download_update_file: The path to the downloaded update file.
    :param vstream_update_file: The target update file path for vstream usage.
    :param src_update_file: The target update file path for src usage.
    :param interval: Time interval (in seconds) between update checks.
    """
    # Create a monitor object to listen for Kodi abort requests.
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        # Check if the installed update file already has the correct hash.
        if not is_installed(download_update_file, vstream_update_file):
            try:
                execute_update_setting(download_update_file, vstream_update_file, src_update_file)
            except Exception as e:
                VSlog(f"[ERROR] Periodic update check failed: {e}")
        # Wait for the specified interval or until an abort is requested.
        if monitor.waitForAbort(interval):
            break
    VSlog("[INFO] Update monitor thread terminated.")

# ---------------------------
# Define file paths and URLs
# ---------------------------

# Define the base path for the service.vstreamupdate addon using VSPath.
vstreamupdate_path = VSPath('special://home/addons/service.vstreamupdate/').replace('\\', '/')

# Define the path to the installed update file for src usage.
src_update_file = os.path.join(vstreamupdate_path, 'resources', 'lib', 'update.py').replace('\\', '/')

# Define the path where the new update file will be downloaded.
download_update_file = os.path.join(vstreamupdate_path, "update.py").replace('\\', '/')

# Define the path to the installed update file for vstream usage.
vstream_update_file = VSPath('special://home/addons/plugin.video.vstream/resources/lib/update.py').replace('\\', '/')

# URL of the new update file to be downloaded.
update_url = "https://raw.githubusercontent.com/Ayuzerak/vupdate/refs/heads/main/update.py"
# URL of the new vupdate file to be downloaded.
vupdate_url = "https://raw.githubusercontent.com/Ayuzerak/vupdate/refs/heads/main/vupdate.py"

if utils.get_setting("updateType") == "update":
    url = update_url
else:
    url = vupdate_url

# -------------------------------------------
# Download and apply the update if necessary
# -------------------------------------------

# Attempt to download the update file.
if download_file(url, download_update_file):
    VSlog(f"[INFO] File saved successfully to {download_update_file}")
    # Execute the update settings based on the downloaded file.
    execute_update_setting(download_update_file, vstream_update_file, src_update_file)

# ------------------------------------------------
# Start a background thread for periodic updates
# ------------------------------------------------

# Create and start a daemon thread that periodically checks for updates.
periodic_thread = threading.Thread(
    target=periodic_update,
    args=(download_update_file, vstream_update_file, src_update_file, 60),  # Check every 60 seconds
    daemon=True
)

periodic_thread.start()
