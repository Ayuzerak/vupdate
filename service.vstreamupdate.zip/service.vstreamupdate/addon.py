import os
import shutil
import time
import hashlib
import re
import threading
import urllib.request
import xbmc
import xbmcvfs
from typing import Optional

from vstream import VStream  # Reintroduced per request
from resources.lib.logger import VSPath, VSlog


def insert_hash_as_comment(file_hash: str, file_path: str) -> None:
    expected_comment = f"# Hash: {file_hash}"
    try:
        # Read the file using xbmcvfs
        f = xbmcvfs.File(file_path, 'r')
        content = f.read()
        f.close()
        lines = content.split('\n')
        
        if any(line.strip() == expected_comment for line in lines):
            VSlog(f"Hash comment is already present in {file_path}")
            return

        # Detect line ending from existing content
        line_ending = '\n'
        if content:
            if '\r\n' in content:
                line_ending = '\r\n'
            elif '\n' in content:
                line_ending = '\n'
            elif '\r' in content:
                line_ending = '\r'

        insertion_index = 0
        for line in lines:
            stripped_line = line.strip()
            if stripped_line == "" or stripped_line.startswith("#"):
                insertion_index += 1
            else:
                break

        # Insert comment with detected line ending
        comment_line = f"{expected_comment}{line_ending}"
        lines.insert(insertion_index, comment_line)

        # Write back using xbmcvfs
        new_content = '\n'.join(lines)
        f = xbmcvfs.File(file_path, 'w')
        success = f.write(new_content)
        f.close()
        if success:
            VSlog(f"Hash comment inserted in: {file_path}")
        else:
            VSlog(f"Failed to write to {file_path}")
    except Exception as e:
        VSlog(f"Error inserting hash comment in {file_path}: {e}")
        raise

def compute_file_hash(file_path: str) -> Optional[str]:
    VSlog(f"Starting hash computation for file: {file_path}")
    try:
        sha256 = hashlib.sha256()
        with xbmcvfs.File(file_path, 'rb') as f:
            while True:
                chunk = f.read(4096)  # Read in 4KB chunks
                if not chunk:
                    break
                sha256.update(chunk)
        hash_result = sha256.hexdigest()
        VSlog(f"Hash computed successfully for file {file_path}: {hash_result}")
        return hash_result
    except Exception as e:
        VSlog(f"Failed to compute hash for file {file_path}. Error: {e}")
        return None

def file_has_hash(file_path: str, expected_hash: str) -> bool:
    """
    Check if the file contains the expected hash comment anywhere in its content.

    :param file_path: The path to the file.
    :param expected_hash: The hash value expected in the comment.
    :return: True if any comment line contains the expected hash; False otherwise.
    """
    try:
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read()
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='ignore')
        for line in content.splitlines():
            stripped_line = line.strip()
            if stripped_line.startswith('#') and f'Hash: {expected_hash}' in stripped_line:
                VSlog(f"[INFO] File {file_path} contains hash: {expected_hash}")
                return True
        return False
    except Exception as e:
        VSlog(f"[ERROR] Failed to check hash in {file_path}: {e}")
        return False


def download_file(url: str, dest_path: str, retries: int = 3, delay: int = 5) -> bool:
    """
    Download a file from a URL with a number of retries.

    :param url: The URL to download.
    :param dest_path: The local file path to save the file.
    :param retries: The number of download attempts.
    :param delay: Delay in seconds between attempts.
    :return: True if the file was downloaded successfully; False otherwise.
    """
    for attempt in range(1, retries + 1):
        try:
            # If the destination file exists, compare its size to the remote file's size.
            if xbmcvfs.exists(dest_path):
                req = urllib.request.Request(url, method='HEAD')
                with urllib.request.urlopen(req) as response:
                    remote_size = response.getheader('Content-Length')
                with xbmcvfs.File(dest_path, 'rb') as f:
                    local_size = f.size()
                if remote_size and int(remote_size) == local_size:
                    VSlog("[INFO] File already downloaded and up to date. Skipping download.")
                    return False

            with urllib.request.urlopen(url) as response:
                data = response.read()
            with xbmcvfs.File(dest_path, 'wb') as f:
                f.write(data)
            VSlog(f"[INFO] Successfully downloaded {url} to {dest_path}")
            return True
        except Exception as e:
            VSlog(f"[WARNING] Download attempt {attempt} failed: {e}")
            time.sleep(delay)
    VSlog(f"[ERROR] Failed to download {url} after {retries} attempts.")
    return False


def update_by_vstream(file_path: str) -> bool:
    """
    Check whether the update file is marked for vstream usage by scanning for a marker.

    :param file_path: The path to the update file.
    :return: True if the file is marked for vstream usage; False otherwise.
    """
    marker_regex = re.compile(r'#\s*update\s+by\s+vstream', re.IGNORECASE)
    
    try:
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read()
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='ignore')
        for line in content.splitlines():
            if marker_regex.search(line):
                return True
        return False
    except Exception as e:
        VSlog(f"[ERROR] Failed to read file {file_path} for update check: {e}")
        return False


def perform_vstream_update(new_update_file: str, installed_update_file: str, is_vstream_update: bool) -> None:
    VSlog(f'[INFO] vstream_update called at {time.strftime("%Y-%m-%d %H:%M:%S")}')
    try:
        if is_vstream_update:
            VSlog("[INFO] update.py marked for vstream usage.")
            success = xbmcvfs.copy(new_update_file, installed_update_file)
            if not success:
                VSlog(f"[ERROR] Failed to copy {new_update_file} to {installed_update_file}")
                return
            VSlog("[INFO] update.py copied successfully.")
        else:
            VSlog("[INFO] update.py marked for vstreamupdate usage.")
            success = xbmcvfs.copy(new_update_file, installed_update_file)
            if not success:
                VSlog(f"[ERROR] Failed to copy {new_update_file} to {installed_update_file}")
                return
            VSlog(f"[INFO] Copied new update.py from {new_update_file} to {installed_update_file}")
            from importlib import reload
            from resources.lib import update
            reload(update)
            from resources.lib.update import cUpdate
            update_instance = cUpdate()
            update_instance.getUpdateSetting()
            VSlog("[INFO] Executed cUpdate().getUpdateSetting() successfully.")
            new_hash = compute_file_hash(new_update_file)
            if new_hash:
                insert_hash_as_comment(new_hash, installed_update_file)
    except Exception as e:
        VSlog(f"[ERROR] vstream update failed: {e}")


def execute_update_setting(download_update_file: str, vstream_update_file: str, src_update_file: str) -> None:
    """
    Execute the update routine by determining the correct target update file based on the marker in the downloaded update file.

    :param download_update_file: The path to the newly downloaded update file.
    :param vstream_update_file: The target update file path for vstream usage.
    :param src_update_file: The target update file path for src usage.
    """
    try:
        is_vstream_update = update_by_vstream(download_update_file)
        if is_vstream_update:
            VSlog("[INFO] New update file is marked for vstream; using vstream_update_file as target.")
            perform_vstream_update(download_update_file, vstream_update_file, is_vstream_update)
        else:
            VSlog("[INFO] New update file is not marked for vstream; using src_update_file as target.")
            perform_vstream_update(download_update_file, src_update_file, is_vstream_update)
    except Exception as e:
        VSlog(f"[ERROR] Failed to execute update function: {e}")


def is_installed(new_file: str, flag_file: str) -> bool:
    """
    Determine whether the installed update file already includes the hash of the new update file.

    :param new_file: The path to the newly downloaded update file.
    :param flag_file: The path to the installed update file to check for the hash comment.
    :return: True if the installed file starts with the correct hash comment; False otherwise.
    """
    new_hash = compute_file_hash(new_file)
    if new_hash is None:
        return False
    return file_has_hash(flag_file, new_hash)


def periodic_update(download_update_file: str, vstream_update_file: str, src_update_file: str, interval: int) -> None:
    """
    Periodically check and execute the update routine.

    :param download_update_file: The path to the downloaded update file.
    :param vstream_update_file: The target update file path for vstream usage.
    :param src_update_file: The target update file path for src usage.
    :param interval: The interval (in seconds) between update checks.
    """
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if not is_installed(download_update_file, vstream_update_file):
            try:
                execute_update_setting(download_update_file, vstream_update_file, src_update_file)
            except Exception as e:
                VSlog(f"[ERROR] Periodic update check failed: {e}")
        if monitor.waitForAbort(interval):
            break
    VSlog("[INFO] Update monitor thread terminated.")


# Define paths for update files.
vstreamupdate_path = VSPath('special://home/addons/service.vstreamupdate/').replace('\\', '/')
src_update_file = os.path.join(vstreamupdate_path, 'resources', 'lib', 'update.py').replace('\\', '/')
download_update_file = os.path.join(vstreamupdate_path, "update.py").replace('\\', '/')
vstream_update_file = VSPath('special://home/addons/plugin.video.vstream/resources/lib/update.py').replace('\\', '/')

# URL of the new update file.
update_url = "https://raw.githubusercontent.com/Ayuzerak/vupdate/refs/heads/main/update.py"

# Download the update file and execute the update if the download was successful.
if download_file(update_url, download_update_file):
    VSlog(f"[INFO] File saved successfully to {download_update_file}")
    execute_update_setting(download_update_file, vstream_update_file, src_update_file)

# Start the periodic update check in a separate daemon thread.
periodic_thread = threading.Thread(
    target=periodic_update,
    args=(download_update_file, vstream_update_file, src_update_file, 60),
    daemon=True
)

periodic_thread.start()
