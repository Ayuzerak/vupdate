# -*- coding: utf-8 -*-
import json
import xbmc
import xbmcaddon
import xbmcvfs
from resources.lib import logger

class VStream:
    """
    A class to interact with the VStream addon in Kodi.
    It can notify VStream with data and manage its installation or activation.
    """
    def __init__(self):
        self.vstream_id = 'plugin.video.vstream'
        self.use_vstream()

    def notifyVStream(self, data=None):
        """
        Notify the VStream addon with data.
        
        Args:
            data (dict): Data to send to the VStream addon.
        
        Returns:
            bool: True if the notification was successful, False otherwise.
        """
        logger.info("notifyVStream called")
        try:
            # Encode the data as JSON
            vstream_data = json.dumps(data)

            # Create the JSON-RPC request
            jsonrpc_request = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "JSONRPC.NotifyAll",
                "params": {
                    "sender": 'service.vstreamupdate.SIGNAL',
                    "message": 'vstream_data',
                    "data": [vstream_data],
                }
            }
            request = json.dumps(jsonrpc_request)
            response = xbmc.executeJSONRPC(request)
            response = json.loads(response)
            
            if response.get('result') == 'OK':
                logger.info("Data successfully notified to VStream.")
                return True
            else:
                logger.error("Failed to notify data to VStream. Response: %s", response)
                return False

        except Exception as e:
            logger.error(f"Error in notifyVStream: {e}")
            return False

    def use_vstream(self):
        """
        Ensure that the VStream addon is installed and enabled.
        
        Returns:
            bool: True if the addon is active or was successfully activated, False otherwise.
        """
        try:
            # Try to load the addon to check if it's installed and enabled
            xbmcaddon.Addon(self.vstream_id)
            logger.info("VStream is already installed and enabled.")
            return True
        except RuntimeError:
            # Addon is either not installed or disabled
            logger.info("VStream is not installed or disabled.")
            
            # Check if the addon exists and enable it if disabled
            addon_xml_path = xbmcvfs.translatePath(f'special://home/addons/{self.vstream_id}/addon.xml')
            if xbmcvfs.exists(addon_xml_path):
                if not xbmcaddon.Addon(self.vstream_id).getAddonInfo('enabled'):
                    xbmcaddon.Addon(self.vstream_id).setAddonInfo('enabled', 'true')
                    logger.info("VStream addon has been enabled successfully.")
                    return True
                else:
                    logger.error("Failed to enable VStream addon.")
                    return False
            else:
                # Install the addon if it's not present
                logger.info("Installing VStream addon.")
                xbmc.executebuiltin(f'InstallAddon({self.vstream_id})')
                logger.info("VStream addon installation initiated.")
                return False  # Return False because installation requires user interaction to complete

        except Exception as e:
            logger.error(f"Error in use_vstream: {e}")
            return False
