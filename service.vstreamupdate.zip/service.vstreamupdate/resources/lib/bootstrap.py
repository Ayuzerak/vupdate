import re
import xml.etree.ElementTree as ET
import traceback
from resources.lib.logger import VSPath, VSlog

class Bootstrap:
    def __init__(self):
        VSlog("Bootstrap::__init__ called.")

    def init(self):
        VSlog("Bootstrap::init called.")
        addon_xml_path = VSPath("special://home/addons/plugin.video.vstream/addon.xml").replace('\\', '/')
        self.insert_import_lines("path/to/addon.xml", ["script.module.regex", "script.module.astor"])

    def insert_import_lines(self, addon_xml_path, import_addons, marker_import="script.module.dnspython"):
        """
        Ensures that addon.xml contains import lines for the specified addons.

        Parameters:
            addon_xml_path: Path to the addon.xml file.
            import_addons: A list of addon names (strings) to be added as <import addon="..."/> elements.
            marker_import: (Optional) If an <import> element with this addon is found within <requires>,
                           the new imports are inserted before it. Otherwise, they are appended at the end.
        """
        VSlog("Bootstrap::insert_import_lines() called.")
        try:
            # Parse the XML file.
            tree = ET.parse(addon_xml_path)
            root = tree.getroot()

            # Locate the <requires> element.
            requires = root.find('requires')
            if requires is None:
                VSlog("No <requires> element found in addon.xml.")
                return

            # Build a set of addons that are already imported.
            existing_imports = {imp.get("addon") for imp in requires.findall("import") if imp.get("addon")}

            # Prepare new import elements for addons that are not yet present.
            new_import_elements = []
            for addon in import_addons:
                if addon in existing_imports:
                    VSlog(f"Import '{addon}' already exists in addon.xml; skipping.")
                else:
                    new_imp = ET.Element("import")
                    new_imp.set("addon", addon)
                    new_import_elements.append(new_imp)
                    VSlog(f"Prepared to add import '{addon}'.")

            if not new_import_elements:
                VSlog("No new imports to add.")
                return

            # Look for the marker import element in <requires>.
            marker_index = None
            for idx, child in enumerate(list(requires)):
                if child.tag == "import" and child.get("addon") == marker_import:
                    marker_index = idx
                    break

            # Insert new import elements.
            if marker_index is not None:
                # Insert new import elements before the marker element.
                for i, new_imp in enumerate(new_import_elements):
                    requires.insert(marker_index + i, new_imp)
                VSlog(f"Inserted {len(new_import_elements)} import(s) before marker import '{marker_import}'.")
            else:
                # Append all new import elements at the end of the <requires> element.
                for new_imp in new_import_elements:
                    requires.append(new_imp)
                VSlog(f"Appended {len(new_import_elements)} import(s) to the <requires> element.")

            # Pretty-print the XML with an 8-space indent (requires Python 3.9+).
            ET.indent(root, space="        ")

            # Write the modified XML back to the file.
            tree.write(addon_xml_path, encoding="utf-8", xml_declaration=True)
            VSlog("Successfully modified addon.xml with the new import lines.")

        except Exception as e:
            VSlog(f"Error modifying addon.xml: {traceback.format_exc()}")
