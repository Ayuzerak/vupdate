#!/usr/bin/env python3
"""
Usage: unparse.py <path to source file or directory>

This file implements an AST unparser that converts a Python AST back into source code.
It supports various Python versions and includes features such as f-string handling,
pattern matching, extended exception handling, configurable formatting, and round-trip testing utilities.
"""

from __future__ import print_function, unicode_literals
import sys
import os
import ast
import tokenize
from io import StringIO
import argparse

# Large float and imaginary literals get turned into infinities in the AST.
INFSTR = "1e" + repr(sys.float_info.max_10_exp + 1)

def interleave(inter, f, seq):
    """
    Call function f on each item in seq, calling inter() between items.
    """
    seq = iter(seq)
    try:
        f(next(seq))
    except StopIteration:
        return
    else:
        for x in seq:
            inter()
            f(x)

class Unparser:
    """
    Unparser traverses an AST and outputs source code for the abstract syntax.
    It supports configurable formatting options.
    """
    # ---- Configuration and Formatting Options ----
    def __init__(self, tree, file=sys.stdout, *, indent_str: str = "    ", compact: bool = False, quote_style: str = None):
        """
        Initialize the Unparser.
        
        Parameters:
            tree: The AST tree to unparse.
            file: The file-like object for output.
            indent_str: String used for indentation (default: 4 spaces).
            compact: If True, produces minified output (less whitespace).
            quote_style: Preferred quote style for string literals (e.g. '"' or "'").
        """
        self.f = file
        self.future_imports = []
        self._indent = 0
        self.indent_str = indent_str
        self.compact = compact
        self.quote_style = quote_style
        self.dispatch(tree)
        print("", file=self.f)
        self.f.flush()

    def fill(self, text: str = "") -> None:
        newline = "" if self.compact else "\n"
        self.f.write(newline + self.indent_str * self._indent + text)

    def write(self, text: str) -> None:
        if self.compact:
            text = text.replace(" ", "")
        self.f.write(text)

    def get_source(self) -> str:
        if hasattr(self.f, "getvalue"):
            return self.f.getvalue()
        raise ValueError("Output file does not support getvalue()")

    def enter(self):
        self.write(":")
        self._indent += 1

    def leave(self):
        self._indent -= 1

    def dispatch(self, tree):
        if isinstance(tree, list):
            for t in tree:
                self.dispatch(t)
            return
        method = getattr(self, "_" + tree.__class__.__name__)
        method(tree)

    # ---- Unparsing Methods for Module and Statements ----
    def _Module(self, tree):
        for stmt in tree.body:
            self.dispatch(stmt)

    def _Interactive(self, tree):
        for stmt in tree.body:
            self.dispatch(stmt)

    def _Expression(self, tree):
        self.dispatch(tree.body)

    def _Expr(self, tree):
        self.fill()
        self.dispatch(tree.value)

    def _NamedExpr(self, tree):
        self.write("(")
        self.dispatch(tree.target)
        self.write(" := ")
        self.dispatch(tree.value)
        self.write(")")

    def _Import(self, t):
        self.fill("import ")
        interleave(lambda: self.write(", "), self.dispatch, t.names)

    def _ImportFrom(self, t):
        if t.module and t.module == '__future__':
            self.future_imports.extend(n.name for n in t.names)
        self.fill("from ")
        self.write("." * t.level)
        if t.module:
            self.write(t.module)
        self.write(" import ")
        interleave(lambda: self.write(", "), self.dispatch, t.names)

    def _Assign(self, t):
        self.fill()
        for target in t.targets:
            self.dispatch(target)
            self.write(" = ")
        self.dispatch(t.value)

    def _AugAssign(self, t):
        self.fill()
        self.dispatch(t.target)
        self.write(" " + self.binop[t.op.__class__.__name__] + "= ")
        self.dispatch(t.value)

    def _AnnAssign(self, t):
        self.fill()
        if not t.simple and isinstance(t.target, ast.Name):
            self.write("(")
        self.dispatch(t.target)
        if not t.simple and isinstance(t.target, ast.Name):
            self.write(")")
        self.write(": ")
        self.dispatch(t.annotation)
        if t.value:
            self.write(" = ")
            self.dispatch(t.value)

    def _Return(self, t):
        self.fill("return")
        if t.value:
            self.write(" ")
            self.dispatch(t.value)

    def _Pass(self, t):
        self.fill("pass")

    def _Break(self, t):
        self.fill("break")

    def _Continue(self, t):
        self.fill("continue")

    def _Delete(self, t):
        self.fill("del ")
        interleave(lambda: self.write(", "), self.dispatch, t.targets)

    def _Assert(self, t):
        self.fill("assert ")
        self.dispatch(t.test)
        if t.msg:
            self.write(", ")
            self.dispatch(t.msg)

    def _Exec(self, t):
        self.fill("exec ")
        self.dispatch(t.body)
        if t.globals:
            self.write(" in ")
            self.dispatch(t.globals)
        if t.locals:
            self.write(", ")
            self.dispatch(t.locals)

    def _Print(self, t):
        self.fill("print ")
        do_comma = False
        if t.dest:
            self.write(">>")
            self.dispatch(t.dest)
            do_comma = True
        for e in t.values:
            if do_comma:
                self.write(", ")
            else:
                do_comma = True
            self.dispatch(e)
        if not t.nl:
            self.write(",")

    def _Global(self, t):
        self.fill("global ")
        interleave(lambda: self.write(", "), self.write, t.names)

    def _Nonlocal(self, t):
        self.fill("nonlocal ")
        interleave(lambda: self.write(", "), self.write, t.names)

    def _Await(self, t):
        self.write("(")
        self.write("await")
        if t.value:
            self.write(" ")
            self.dispatch(t.value)
        self.write(")")

    def _Yield(self, t):
        self.write("(")
        self.write("yield")
        if t.value:
            self.write(" ")
            self.dispatch(t.value)
        self.write(")")

    def _YieldFrom(self, t):
        self.write("(")
        self.write("yield from")
        if t.value:
            self.write(" ")
            self.dispatch(t.value)
        self.write(")")

    def _Raise(self, t):
        self.fill("raise")
        if not t.exc:
            return
        self.write(" ")
        self.dispatch(t.exc)
        if t.cause:
            self.write(" from ")
            self.dispatch(t.cause)

    def _Try(self, t):
        self.fill("try")
        self.enter()
        self.dispatch(t.body)
        self.leave()
        for ex in t.handlers:
            self.dispatch(ex)
        if t.orelse:
            self.fill("else")
            self.enter()
            self.dispatch(t.orelse)
            self.leave()
        if t.finalbody:
            self.fill("finally")
            self.enter()
            self.dispatch(t.finalbody)
            self.leave()

    def _TryExcept(self, t):
        self.fill("try")
        self.enter()
        self.dispatch(t.body)
        self.leave()
        for ex in t.handlers:
            self.dispatch(ex)
        if t.orelse:
            self.fill("else")
            self.enter()
            self.dispatch(t.orelse)
            self.leave()

    def _TryFinally(self, t):
        if len(t.body) == 1 and isinstance(t.body[0], ast.TryExcept):
            self.dispatch(t.body)
        else:
            self.fill("try")
            self.enter()
            self.dispatch(t.body)
            self.leave()
        self.fill("finally")
        self.enter()
        self.dispatch(t.finalbody)
        self.leave()

    def _ClassDef(self, t):
        self.write("\n")
        for deco in t.decorator_list:
            self.fill("@")
            self.dispatch(deco)
        self.fill("class " + t.name)
        self.write("(")
        comma = False
        for e in t.bases:
            if comma:
                self.write(", ")
            else:
                comma = True
            self.dispatch(e)
        for e in t.keywords:
            if comma:
                self.write(", ")
            else:
                comma = True
            self.dispatch(e)
        self.write(")")
        self.enter()
        self.dispatch(t.body)
        self.leave()

    def _FunctionDef(self, t):
        self.write("\n")
        for deco in t.decorator_list:
            self.fill("@")
            self.dispatch(deco)
        self.fill("def " + t.name + "(")
        self.dispatch(t.args)
        self.write(")")
        if getattr(t, "returns", False):
            self.write(" -> ")
            self.dispatch(t.returns)
        self.enter()
        self.dispatch(t.body)
        self.leave()

    def _AsyncFunctionDef(self, t):
        self.write("\n")
        for deco in t.decorator_list:
            self.fill("@")
            self.dispatch(deco)
        self.fill("async def " + t.name + "(")
        self.dispatch(t.args)
        self.write(")")
        if getattr(t, "returns", False):
            self.write(" -> ")
            self.dispatch(t.returns)
        self.enter()
        self.dispatch(t.body)
        self.leave()

    def _For(self, t):
        self.fill("for ")
        self.dispatch(t.target)
        self.write(" in ")
        self.dispatch(t.iter)
        self.enter()
        self.dispatch(t.body)
        self.leave()
        if t.orelse:
            self.fill("else")
            self.enter()
            self.dispatch(t.orelse)
            self.leave()

    def _AsyncFor(self, t):
        self.fill("async for ")
        self.dispatch(t.target)
        self.write(" in ")
        self.dispatch(t.iter)
        self.enter()
        self.dispatch(t.body)
        self.leave()
        if t.orelse:
            self.fill("else")
            self.enter()
            self.dispatch(t.orelse)
            self.leave()

    def _If(self, t):
        self.fill("if ")
        self.dispatch(t.test)
        self.enter()
        self.dispatch(t.body)
        self.leave()
        while t.orelse and len(t.orelse) == 1 and isinstance(t.orelse[0], ast.If):
            t = t.orelse[0]
            self.fill("elif ")
            self.dispatch(t.test)
            self.enter()
            self.dispatch(t.body)
            self.leave()
        if t.orelse:
            self.fill("else")
            self.enter()
            self.dispatch(t.orelse)
            self.leave()

    def _While(self, t):
        self.fill("while ")
        self.dispatch(t.test)
        self.enter()
        self.dispatch(t.body)
        self.leave()
        if t.orelse:
            self.fill("else")
            self.enter()
            self.dispatch(t.orelse)
            self.leave()

    def _With(self, t):
        self.fill("with ")
        self.dispatch(t.context_expr)
        if t.optional_vars:
            self.write(" as ")
            self.dispatch(t.optional_vars)
        self.enter()
        self.dispatch(t.body)
        self.leave()

    def _AsyncWith(self, t):
        self.fill("async with ")
        self.dispatch(t.context_expr)
        if t.optional_vars:
            self.write(" as ")
            self.dispatch(t.optional_vars)
        self.enter()
        self.dispatch(t.body)
        self.leave()

    # ---- Unparsing Methods for Expressions ----
    def _Bytes(self, t):
        self.write(repr(t.s))

    def _Str(self, t):
        self.write(repr(t.s))

    def _JoinedStr(self, t):
        self.write("f")
        buf = StringIO()
        self._fstring_JoinedStr(t, buf.write)
        s = buf.getvalue()
        if "\n" in s or "\r" in s:
            quotes = ["'''", '"""']
        else:
            quotes = ["'", '"', "'''", '"""']
        if self.quote_style:
            q = self.quote_style
            if q in s:
                self.write(repr(s))
            else:
                self.write(q + s + q)
        else:
            for q in quotes:
                if q not in s:
                    self.write(q + s + q)
                    return
            self.write(repr(s))

    def _FormattedValue(self, t):
        self.write("{")
        self.dispatch(t.value)
        if t.conversion != -1:
            self.write("!" + chr(t.conversion))
        if t.format_spec:
            self.write(":")
            self.dispatch(t.format_spec)
        self.write("}")

    def _fstring_JoinedStr(self, t, write):
        for value in t.values:
            meth = getattr(self, "_fstring_" + type(value).__name__)
            meth(value, write)

    def _fstring_Str(self, t, write):
        write(t.s.replace("{", "{{").replace("}", "}}"))

    def _fstring_Constant(self, t, write):
        assert isinstance(t.value, str)
        write(t.value.replace("{", "{{").replace("}", "}}"))

    def _fstring_FormattedValue(self, t, write):
        write("{")
        buf = StringIO()
        Unparser(t.value, buf)
        expr = buf.getvalue().rstrip("\n")
        write(expr)
        if t.conversion != -1:
            write("!" + chr(t.conversion))
        if t.format_spec:
            write(":")
            meth = getattr(self, "_fstring_" + type(t.format_spec).__name__)
            meth(t.format_spec, write)
        write("}")

    def _Name(self, t):
        self.write(t.id)

    def _NameConstant(self, t):
        self.write(repr(t.value))

    def _Repr(self, t):
        self.write("`")
        self.dispatch(t.value)
        self.write("`")

    def _write_constant(self, value):
        if isinstance(value, (float, complex)):
            self.write(repr(value).replace("inf", INFSTR))
        else:
            self.write(repr(value))

    def _Constant(self, t):
        value = t.value
        if isinstance(value, tuple):
            self.write("(")
            if len(value) == 1:
                self._write_constant(value[0])
                self.write(",")
            else:
                interleave(lambda: self.write(", "), self._write_constant, value)
            self.write(")")
        elif value is Ellipsis:
            self.write("...")
        else:
            self._write_constant(value)

    def _Num(self, t):
        self.write(repr(t.n))

    def _List(self, t):
        self.write("[")
        interleave(lambda: self.write(", "), self.dispatch, t.elts)
        self.write("]")

    def _ListComp(self, t):
        self.write("[")
        self.dispatch(t.elt)
        for gen in t.generators:
            self.dispatch(gen)
        self.write("]")

    def _GeneratorExp(self, t):
        self.write("(")
        self.dispatch(t.elt)
        for gen in t.generators:
            self.dispatch(gen)
        self.write(")")

    def _SetComp(self, t):
        self.write("{")
        self.dispatch(t.elt)
        for gen in t.generators:
            self.dispatch(gen)
        self.write("}")

    def _DictComp(self, t):
        self.write("{")
        self.dispatch(t.key)
        self.write(": ")
        self.dispatch(t.value)
        for gen in t.generators:
            self.dispatch(gen)
        self.write("}")

    def _comprehension(self, t):
        if getattr(t, 'is_async', False):
            self.write(" async for ")
        else:
            self.write(" for ")
        self.dispatch(t.target)
        self.write(" in ")
        self.dispatch(t.iter)
        for if_clause in t.ifs:
            self.write(" if ")
            self.dispatch(if_clause)

    def _IfExp(self, t):
        self.write("(")
        self.dispatch(t.body)
        self.write(" if ")
        self.dispatch(t.test)
        self.write(" else ")
        self.dispatch(t.orelse)
        self.write(")")

    def _Set(self, t):
        assert t.elts, "Set literal must have at least one element"
        self.write("{")
        interleave(lambda: self.write(", "), self.dispatch, t.elts)
        self.write("}")

    def _Dict(self, t):
        self.write("{")
        def write_pair(pair):
            k, v = pair
            self.dispatch(k)
            self.write(": ")
            self.dispatch(v)
        interleave(lambda: self.write(", "), write_pair, zip(t.keys, t.values))
        self.write("}")

    def _Tuple(self, t):
        self.write("(")
        if len(t.elts) == 1:
            self.dispatch(t.elts[0])
            self.write(",")
        else:
            interleave(lambda: self.write(", "), self.dispatch, t.elts)
        self.write(")")

    unop = {"Invert": "~", "Not": "not", "UAdd": "+", "USub": "-"}
    binop = {
        "Add": "+", "Sub": "-", "Mult": "*", "Div": "/", "Mod": "%",
        "LShift": "<<", "RShift": ">>", "BitOr": "|", "BitXor": "^",
        "BitAnd": "&", "FloorDiv": "//", "Pow": "**"
    }
    cmpops = {
        "Eq": "==", "NotEq": "!=", "Lt": "<", "LtE": "<=", "Gt": ">",
        "GtE": ">=", "Is": "is", "IsNot": "is not", "In": "in", "NotIn": "not in"
    }
    boolops = {ast.And: "and", ast.Or: "or"}

    def _UnaryOp(self, t):
        self.write("(")
        self.write(self.unop[t.op.__class__.__name__])
        self.write(" ")
        if isinstance(t.op, ast.USub) and isinstance(t.operand, ast.Num):
            self.write("(")
            self.dispatch(t.operand)
            self.write(")")
        else:
            self.dispatch(t.operand)
        self.write(")")

    def _BinOp(self, t):
        self.write("(")
        self.dispatch(t.left)
        self.write(" " + self.binop[t.op.__class__.__name__] + " ")
        self.dispatch(t.right)
        self.write(")")

    def _Compare(self, t):
        self.write("(")
        self.dispatch(t.left)
        for op, comp in zip(t.ops, t.comparators):
            self.write(" " + self.cmpops[op.__class__.__name__] + " ")
            self.dispatch(comp)
        self.write(")")

    def _BoolOp(self, t):
        self.write("(")
        s = " %s " % self.boolops[t.op.__class__]
        interleave(lambda: self.write(s), self.dispatch, t.values)
        self.write(")")

    def _Attribute(self, t):
        self.dispatch(t.value)
        if isinstance(t.value, ast.Num) and isinstance(t.value.n, int):
            self.write(" ")
        self.write(".")
        self.write(t.attr)

    def _Call(self, t):
        self.dispatch(t.func)
        self.write("(")
        comma = False
        for e in t.args:
            if comma:
                self.write(", ")
            else:
                comma = True
            self.dispatch(e)
        for e in t.keywords:
            if comma:
                self.write(", ")
            else:
                comma = True
            self.dispatch(e)
        if getattr(t, 'starargs', None):
            if comma:
                self.write(", ")
            else:
                comma = True
            self.write("*")
            self.dispatch(t.starargs)
        if getattr(t, 'kwargs', None):
            if comma:
                self.write(", ")
            else:
                comma = True
            self.write("**")
            self.dispatch(t.kwargs)
        self.write(")")

    def _Subscript(self, t):
        self.dispatch(t.value)
        self.write("[")
        self.dispatch(t.slice)
        self.write("]")

    def _Starred(self, t):
        self.write("*")
        self.dispatch(t.value)

    def _Ellipsis(self, t):
        self.write("...")

    def _Index(self, t):
        self.dispatch(t.value)

    def _Slice(self, t):
        if t.lower:
            self.dispatch(t.lower)
        self.write(":")
        if t.upper:
            self.dispatch(t.upper)
        if t.step:
            self.write(":")
            self.dispatch(t.step)

    def _ExtSlice(self, t):
        interleave(lambda: self.write(", "), self.dispatch, t.dims)

    def _arguments(self, t):
        first = True
        defaults = [None] * (len(t.args) - len(t.defaults)) + t.defaults
        for a, d in zip(t.args, defaults):
            if first:
                first = False
            else:
                self.write(", ")
            self.dispatch(a)
            if d:
                self.write("=")
                self.dispatch(d)
        if getattr(t, 'vararg', None):
            if first:
                first = False
            else:
                self.write(", ")
            self.write("*" + t.vararg)
        if getattr(t, 'kwarg', None):
            if first:
                first = False
            else:
                self.write(", ")
            self.write("**" + t.kwarg)

    def _keyword(self, t):
        self.write(t.arg)
        self.write("=")
        self.dispatch(t.value)

    def _Lambda(self, t):
        self.write("(")
        self.write("lambda ")
        self.dispatch(t.args)
        self.write(": ")
        self.dispatch(t.body)
        self.write(")")

    def _alias(self, t):
        self.write(t.name)
        if t.asname:
            self.write(" as " + t.asname)

# ---- Round-Trip Testing and Verification Utilities ----

def round_trip_source(source: str, filename: str = "<unknown>") -> str:
    """
    Given source code as a string, parse it into an AST,
    unparse it back into source code using the Unparser,
    and return the resulting source code.
    """
    try:
        tree = ast.parse(source, filename, "exec", ast.PyCF_ONLY_AST)
    except Exception as e:
        raise ValueError(f"Error parsing source in {filename}: {e}")
    buf = StringIO()
    Unparser(tree, buf)
    return buf.getvalue()

def round_trip_test_file(filename: str) -> bool:
    """
    Perform a round-trip test on the given file.
    Reads the file, generates its AST, then unparse it back to source,
    reparses the new source, and compares AST dumps for equivalence.
    Returns True if they match, otherwise False.
    """
    try:
        with open(filename, "r", encoding="utf-8") as f:
            original_source = f.read()
    except Exception as e:
        print(f"Error reading {filename}: {e}", file=sys.stderr)
        return False
    try:
        original_tree = ast.parse(original_source, filename, "exec")
    except Exception as e:
        print(f"Error parsing {filename}: {e}", file=sys.stderr)
        return False
    try:
        new_source = round_trip_source(original_source, filename)
        new_tree = ast.parse(new_source, filename, "exec")
    except Exception as e:
        print(f"Error in round-trip processing for {filename}: {e}", file=sys.stderr)
        return False

    if ast.dump(original_tree) == ast.dump(new_tree):
        print(f"Round-trip test succeeded for {filename}")
        return True
    else:
        print(f"Round-trip test FAILED for {filename}", file=sys.stderr)
        print("Original AST:", ast.dump(original_tree, indent=4))
        print("Reparsed AST:", ast.dump(new_tree, indent=4))
        return False

def round_trip_test_dir(directory: str) -> None:
    """
    Recursively perform round-trip tests on all Python (.py) files within the directory.
    """
    if not os.path.isdir(directory):
        print(f"Not a directory: {directory}", file=sys.stderr)
        return
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(".py"):
                full_path = os.path.join(root, file)
                round_trip_test_file(full_path)

def main() -> None:
    """
    Command-line interface for the unparser.
    If --test is specified, performs round-trip testing.
    Otherwise, unparse and output the source code.
    """
    parser = argparse.ArgumentParser(
        description="Unparse a Python AST back into source code and perform round-trip testing."
    )
    parser.add_argument(
        "paths", nargs="+", help="Path(s) to Python file(s) or directory(ies) to process."
    )
    parser.add_argument(
        "--test", action="store_true", help="Perform round-trip testing instead of plain unparse."
    )
    parser.add_argument(
        "--indent", type=str, default="    ", help="Indentation string (default: 4 spaces)."
    )
    parser.add_argument(
        "--compact", action="store_true", help="Produce compact (minified) output."
    )
    parser.add_argument(
        "--quote", type=str, default=None, help="Preferred quote style for string literals."
    )
    args = parser.parse_args()

    if args.test:
        for path in args.paths:
            if os.path.isdir(path):
                round_trip_test_dir(path)
            else:
                round_trip_test_file(path)
    else:
        for path in args.paths:
            if os.path.isdir(path):
                round_trip_test_dir(path)
            else:
                with open(path, "r", encoding="utf-8") as f:
                    source = f.read()
                tree = ast.parse(source, path, "exec", ast.PyCF_ONLY_AST)
                Unparser(tree, sys.stdout, indent_str=args.indent, compact=args.compact, quote_style=args.quote)

if __name__ == "__main__":
    main()
