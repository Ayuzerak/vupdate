import xbmc
import xbmcvfs
import shutil
import os
import urllib.request
import time
import hashlib
import threading
from vstream import VStream
from resources.lib.logger import VSPath, VSlog

def vstream_update():
    VSlog(f'[INFO] vstream_update called at {time.strftime("%Y-%m-%d %H:%M:%S")}')
    from resources.lib.update import cUpdate
    update_instance = cUpdate()
    update_instance.getUpdateSetting()

def hash_file(file_path):
    """Generate SHA256 hash of a file for comparison."""
    if not os.path.isfile(file_path):
        return None
    hasher = hashlib.sha256()
    try:
        with open(file_path, 'rb') as f:
            while chunk := f.read(4096):
                hasher.update(chunk)
        return hasher.hexdigest()
    except Exception as e:
        VSlog(f"[ERROR] Failed to hash file {file_path}: {e}")
        return None

def download_file(url, dest_path, retries=3, delay=5):
    """Download a file with retries."""
    for attempt in range(retries):
        try:
            if os.path.exists(dest_path):
                req = urllib.request.Request(url, method='HEAD')
                with urllib.request.urlopen(req) as response:
                    remote_size = response.getheader('Content-Length')
                if remote_size and int(remote_size) == os.path.getsize(dest_path):
                    VSlog("[INFO] File already downloaded and up to date. Skipping.")
                    return True

            with urllib.request.urlopen(url) as response, open(dest_path, 'wb') as out_file:
                out_file.write(response.read())
            VSlog(f"[INFO] Successfully downloaded {url} to {dest_path}")
            return True
        except Exception as e:
            VSlog(f"[WARNING] Download attempt {attempt+1} failed: {e}")
            time.sleep(delay)
    VSlog(f"[ERROR] Failed to download {url} after {retries} attempts.")
    return False

def execute_update_setting():
    """Dynamically reload the update module and execute its update routine."""
    try:
        vstream_update()
        VSlog("[INFO] Executed cUpdate().getUpdateSetting() successfully.")
    except Exception as e:
        VSlog(f"[ERROR] Failed to execute update function: {e}")

def raw_vstream():
    monitor_py = VSPath('special://home/addons/plugin.video.vstream/resources/lib/monitor.py').replace('\\', '/')
    return not os.path.exists(monitor_py)

def update_by_vstream(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        first_line = f.readline().strip().lower()  # Normalize case
        return "#update by vstream" in first_line  # Check if the phrase is present

def periodic_update(interval):
    """Runs a periodic check for updates."""
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if raw_vstream():
            try:
                execute_update_setting()
            except Exception as e:
                VSlog(f"[ERROR] Periodic check failed: {e}")
        
        if monitor.waitForAbort(interval):
            break
    VSlog("[INFO] Update monitor thread terminated.")

# Define paths for updates
vstreamupdate_path = VSPath('special://home/addons/service.vstreamupdate/').replace('\\', '/')
src_update_file = os.path.join(vstreamupdate_path, 'resources', 'lib', 'update.py').replace('\\', '/')
new_update_file = os.path.join(vstreamupdate_path, "update.py").replace('\\', '/')
vstream_update_file = VSPath('special://home/addons/plugin.video.vstream/resources/lib/update.py').replace('\\', '/')

# Download the update file if needed
sUrl = "https://raw.githubusercontent.com/Ayuzerak/vupdate/refs/heads/main/update.py"
# if download_file(sUrl, new_update_file):
#     VSlog(f"[INFO] File saved successfully to {new_update_file}")

# Only copy if the file is different based on hash comparison
if os.path.isfile(new_update_file):
    try:
        if update_by_vstream(new_update_file):
            shutil.copy(new_update_file, vstream_update_file)
            os._exit(0)

        old_hash = hash_file(src_update_file)
        new_hash = hash_file(new_update_file)

        if old_hash != new_hash:
            shutil.copy(new_update_file, src_update_file)
            VSlog(f"[INFO] Copied new update.py from {new_update_file} to {src_update_file}")
            execute_update_setting()
        else:
            VSlog("[INFO] update.py is already up to date.")
    except Exception as e:
        VSlog(f"[ERROR] Failed to copy new update.py: {e}")

# Start the periodic check in a separate daemon thread
periodic_thread = threading.Thread(target=periodic_update, args=(60,), daemon=True)
periodic_thread.start()
