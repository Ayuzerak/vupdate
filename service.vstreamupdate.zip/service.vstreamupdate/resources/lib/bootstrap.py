import re
from resources.lib.logger import VSPath, VSlog

class Bootstrap:
    def __init__(self):
        VSlog("Bootstrap::__init__ called.")

    def init(self):
        VSlog("Bootstrap::init called.")
        addon_xml_path = VSPath("special://home/addons/plugin.video.vstream/addon.xml").replace('\\', '/')
        self.insert_regex_import_line(addon_xml_path)

    def insert_regex_import_line(self, addon_xml_path):
        """
        Ensures that addon.xml contains:
            <import addon="script.module.regex"/>
        If missing, inserts before:
            <import addon="script.module.dnspython" optional="true"/>
        Or before the closing </requires> tag otherwise.

        Args:
            addon_xml_path (str): The path to the addon.xml file.
        """
        VSlog("Bootstrap::insert_regex_import_line() called.")

        try:
            with open(addon_xml_path, 'r', encoding='utf-8', errors='replace') as file:
                content = file.read()

            # Check if regex import line already exists
            if re.search(r'<import\s+addon="script\.module\.regex"', content):
                VSlog("The regex import line is already present.")
                return

            new_content = content

            # Find the dnspython import line and capture its indentation
            dnspython_match = re.search(r'(\s*)(<import\s+addon="script\.module\.dnspython".*?>)', content)
            if dnspython_match:
                indent = dnspython_match.group(1)  # Capture leading spaces/tabs
                regex_import_line = f'{indent}<import addon="script.module.regex"/>\n'
                new_content = content.replace(dnspython_match.group(2), regex_import_line + dnspython_match.group(2))
            else:
                # Otherwise, insert before </requires>
                requires_match = re.search(r'(\s*)(</requires>)', content)
                if requires_match:
                    indent = requires_match.group(1)
                    regex_import_line = f'{indent}<import addon="script.module.regex"/>\n'
                    new_content = content.replace(requires_match.group(2), regex_import_line + requires_match.group(2))
                else:
                    # If </requires> isn't found, append at the end with a default indentation
                    new_content = content + "\n    <import addon=\"script.module.regex\"/>\n"

            # Write the modified content back
            with open(addon_xml_path, 'w', encoding='utf-8') as file:
                file.write(new_content)

            VSlog("Successfully inserted the regex import line with correct indentation.")
        
        except Exception as e:
            VSlog(f"Error modifying addon.xml: {e}")
