import os
import shutil
import time
import hashlib
import threading
import urllib.request
import xbmc
import xbmcvfs
from typing import Optional

from vstream import VStream
from resources.lib.logger import VSPath, VSlog


def insert_hash_as_comment(file_hash: str, file_path: str) -> None:
    """
    Insert the given hash as a comment into the file, immediately after any initial comment or blank lines,
    but only if the correct hash comment is not already present anywhere in the file.

    :param file_hash: The hash string to insert.
    :param file_path: The path of the file to update.
    """
    if not file_hash:
        return
    try:
        # Check if the file already contains the correct hash comment anywhere.
        if file_has_hash(file_path, file_hash):
            VSlog(f"[INFO] File {file_path} already contains the correct hash comment. Skipping insertion.")
            return

        # Read the existing content using xbmcvfs in binary mode.
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read().decode('utf-8')

        # Split the content into lines.
        lines = content.splitlines()

        # Determine the insertion point: after the initial block of comment or blank lines.
        insertion_index = 0
        for line in lines:
            stripped_line = line.lstrip()
            if stripped_line.startswith('#') or not stripped_line:
                insertion_index += 1
            else:
                break

        # Create the hash comment line.
        hash_line = f'# Hash: {file_hash}'

        # Insert the hash comment after the initial comment block.
        new_lines = lines[:insertion_index] + [hash_line] + lines[insertion_index:]

        # Reassemble the content, preserving newlines.
        new_content = "\n".join(new_lines)
        if content.endswith('\n'):
            new_content += '\n'

        # Write the updated content back to the file.
        with xbmcvfs.File(file_path, 'wb') as f:
            f.write(new_content.encode('utf-8'))

        VSlog(f"[INFO] Hash comment added to {file_path}")
    except Exception as e:
        VSlog(f"[ERROR] Failed to insert hash comment into {file_path}: {e}")

def compute_file_hash(file_path: str) -> Optional[str]:
    """
    Compute the SHA256 hash of a file.

    :param file_path: The path of the file to hash.
    :return: The hexadecimal SHA256 hash, or None if an error occurs or the file does not exist.
    """
    if not xbmcvfs.exists(file_path):
        return None
    hasher = hashlib.sha256()
    try:
        with xbmcvfs.File(file_path, 'rb') as f:
            while True:
                chunk = f.read(4096)
                if not chunk:
                    break
                # Ensure chunk is bytes. If it's a Unicode string, encode it.
                if isinstance(chunk, str):
                    chunk = chunk.encode('utf-8')
                hasher.update(chunk)
        return hasher.hexdigest()
    except Exception as e:
        VSlog(f"[ERROR] Failed to compute hash for {file_path}: {e}")
        return None

def file_has_hash(file_path: str, expected_hash: str) -> bool:
    """
    Check if the file contains the expected hash comment anywhere in its content.

    This function scans through each line of the file and returns True if any line 
    that is a comment (i.e. starts with '#') contains the string "Hash: {expected_hash}".

    :param file_path: The path to the file.
    :param expected_hash: The hash value expected in the comment.
    :return: True if any comment line contains the expected hash; False otherwise.
    """
    try:
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read().decode('utf-8')
        for line in content.splitlines():
            stripped_line = line.strip()
            if stripped_line.startswith('#') and f'Hash: {expected_hash}' in stripped_line:
                return True
        return False
    except Exception as e:
        VSlog(f"[ERROR] Failed to check hash in {file_path}: {e}")
        return False


def download_file(url: str, dest_path: str, retries: int = 3, delay: int = 5) -> bool:
    """
    Download a file from a URL with a number of retries.

    :param url: The URL to download.
    :param dest_path: The local file path to save the file.
    :param retries: The number of download attempts.
    :param delay: Delay in seconds between attempts.
    :return: True if the file was downloaded successfully; False if the file was already up to date or if the download failed.
    """
    for attempt in range(1, retries + 1):
        try:
            # If the destination file exists, compare its size to the remote file's size.
            if xbmcvfs.exists(dest_path):
                # Use a HEAD request to get the remote file size.
                req = urllib.request.Request(url, method='HEAD')
                with urllib.request.urlopen(req) as response:
                    remote_size = response.getheader('Content-Length')
                # Get the local file size using xbmcvfs.
                with xbmcvfs.File(dest_path, 'rb') as f:
                    local_size = f.size()
                if remote_size and int(remote_size) == local_size:
                    VSlog("[INFO] File already downloaded and up to date. Skipping download.")
                    return False

            # Download the file content from the URL.
            with urllib.request.urlopen(url) as response:
                data = response.read()
            with xbmcvfs.File(dest_path, 'wb') as f:
                f.write(data)
            VSlog(f"[INFO] Successfully downloaded {url} to {dest_path}")
            return True
        except Exception as e:
            VSlog(f"[WARNING] Download attempt {attempt} failed: {e}")
            time.sleep(delay)
    VSlog(f"[ERROR] Failed to download {url} after {retries} attempts.")
    return False

def update_by_vstream(file_path: str) -> bool:
    """
    Check whether the update file is marked for vstream usage by inspecting its first line.

    :param file_path: The path to the update file.
    :return: True if the marker "#update by vstream" is present in the first line; False otherwise.
    """
    try:
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read()
            # Ensure we have a string for processing.
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='ignore')
            lines = content.splitlines()
            first_line = lines[0].strip().lower() if lines else ""
        return "#update by vstream" in first_line
    except Exception as e:
        VSlog(f"[ERROR] Failed to read file {file_path} for update check: {e}")
        return False

def perform_vstream_update(new_update_file: str, installed_update_file: str, is_vstream_update: bool) -> None:
    """
    Perform the update routine for vstream.

    Depending on the update marker, this function either simply copies the new update file
    or reloads the update module and executes its update setting.

    :param new_update_file: The path to the newly downloaded update file.
    :param installed_update_file: The path to the currently installed update file.
    :param is_vstream_update: Boolean flag indicating whether the update is for vstream usage.
    """
    VSlog(f'[INFO] vstream_update called at {time.strftime("%Y-%m-%d %H:%M:%S")}')
    try:
        if is_vstream_update:
            VSlog("[INFO] update.py marked for vstream usage.")
            shutil.copy(new_update_file, installed_update_file)
            VSlog("[INFO] update.py copied successfully.")
        else:
            VSlog("[INFO] update.py marked for vstreamupdate usage.")
            shutil.copy(new_update_file, installed_update_file)
            VSlog(f"[INFO] Copied new update.py from {new_update_file} to {installed_update_file}")
            # Reload the module to ensure the new code is used.
            from importlib import reload
            from resources.lib import update
            reload(update)
            from resources.lib.update import cUpdate
            update_instance = cUpdate()
            update_instance.getUpdateSetting()
            VSlog("[INFO] Executed cUpdate().getUpdateSetting() successfully.")
            new_hash = compute_file_hash(new_update_file)
            insert_hash_as_comment(new_hash, installed_update_file)
    except Exception as e:
        VSlog(f"[ERROR] vstream update failed: {e}")


def execute_update_setting(download_update_file: str, vstream_update_file: str, src_update_file: str) -> None:
    """
    Execute the update routine by determining the correct target update file based on the marker in the downloaded update file.

    :param download_update_file: The path to the newly downloaded update file.
    :param vstream_update_file: The target update file path for vstream usage.
    :param src_update_file: The target update file path for src usage.
    """
    try:
        # Determine if the downloaded update file is marked for vstream usage.
        is_vstream_update = update_by_vstream(download_update_file)
        if is_vstream_update:
            VSlog("[INFO] New update file is marked for vstream; using vstream_update_file as target.")
        else:
            VSlog("[INFO] New update file is not marked for vstream; using src_update_file as target.")

        perform_vstream_update(download_update_file, vstream_update_file, is_vstream_update)
    except Exception as e:
        VSlog(f"[ERROR] Failed to execute update function: {e}")


def is_installed(new_file: str, flag_file: str) -> bool:
    """
    Determine whether the installed update file already includes the hash of the new update file.

    :param new_file: The path to the newly downloaded update file.
    :param flag_file: The path to the installed update file to check for the hash comment.
    :return: True if the installed file starts with the correct hash comment; False otherwise.
    """
    new_hash = compute_file_hash(new_file)
    if new_hash is None:
        return False
    return file_has_hash(flag_file, new_hash)


def periodic_update(download_update_file: str, vstream_update_file: str, src_update_file: str, interval: int) -> None:
    """
    Periodically check and execute the update routine.

    :param download_update_file: The path to the downloaded update file.
    :param vstream_update_file: The target update file path for vstream usage.
    :param src_update_file: The target update file path for src usage.
    :param interval: The interval (in seconds) between update checks.
    """
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        # Check if the new update file is already installed by comparing its hash comment.
        if not is_installed(download_update_file, vstream_update_file):
            try:
                execute_update_setting(download_update_file, vstream_update_file, src_update_file)
            except Exception as e:
                VSlog(f"[ERROR] Periodic update check failed: {e}")
        # Wait for the specified interval or until an abort is requested.
        if monitor.waitForAbort(interval):
            break
    VSlog("[INFO] Update monitor thread terminated.")


# Define paths for update files.
vstreamupdate_path = VSPath('special://home/addons/service.vstreamupdate/').replace('\\', '/')
src_update_file = os.path.join(vstreamupdate_path, 'resources', 'lib', 'update.py').replace('\\', '/')
download_update_file = os.path.join(vstreamupdate_path, "update.py").replace('\\', '/')
vstream_update_file = VSPath('special://home/addons/plugin.video.vstream/resources/lib/update.py').replace('\\', '/')

# URL of the new update file.
update_url = "https://raw.githubusercontent.com/Ayuzerak/vupdate/refs/heads/main/update.py"

# Download the update file and execute the update if the download was successful.
if download_file(update_url, download_update_file):
    VSlog(f"[INFO] File saved successfully to {download_update_file}")
    # Perform the update immediately after download.
    execute_update_setting(download_update_file, vstream_update_file, src_update_file)

# Start the periodic update check in a separate daemon thread.
periodic_thread = threading.Thread(
    target=periodic_update,
    args=(download_update_file, vstream_update_file, src_update_file, 60),
    daemon=True
)
periodic_thread.start()
