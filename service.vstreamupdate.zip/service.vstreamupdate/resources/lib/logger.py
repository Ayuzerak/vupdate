import sys
import xbmc
import xbmcvfs

def _log(message):
    log_message = f'[vStream Update] {message}'
    if sys.version_info >= (3,):
        encoded_message_data = log_message
    else:
        encoded_message_data = log_message.encode('utf-8')
    xbmc.log(encoded_message_data, level=xbmc.LOGDEBUG)

def debug(message):
    _log(message)

def error(message):
    _log(f'[ERROR] {message}')

def info(message):
    _log(f'[INFO] {message}')

def VSlog(message):
    xbmc.log(f"[vStream Update]: {message}", level=xbmc.LOGINFO)

def isMatrix():
    try:
        version = xbmc.getInfoLabel('system.buildversion')
        if version[0:2] >= '19':
            return True
        else:
            return False
    except Exception:
        return False

def VSPath(pathSpecial):
    if isMatrix():
        path = xbmcvfs.translatePath(pathSpecial)
    else:
        path = xbmc.translatePath(pathSpecial)
    return path