import os                # For operating system path and file operations
import shutil            # For file operations (if needed; here we use xbmcvfs mostly)
import time              # For delays, time stamps, and periodic checks
import hashlib           # For computing SHA-256 file hashes
import re                # For regular expression matching
import threading         # To run periodic update checks in a background thread
import urllib.request    # To download update files from a remote URL
import xbmc              # Kodi’s xbmc module (used for monitoring Kodi’s abort signal)
import xbmcvfs           # Kodi’s virtual file system module for file I/O operations
from typing import Optional  # For optional type hints

# Import VStream module (reintroduced per request)
from vstream import VStream

# Import custom logger and path helper from the addon's resources.
from resources.lib.logger import VSPath, VSlog


def insert_hash_as_comment(file_hash: str, file_path: str) -> None:
    """
    Inserts a hash comment (e.g., "# Hash: <hash>") at the top of a file.
    The comment is inserted after any leading blank or comment lines.
    
    :param file_hash: The hash value to insert.
    :param file_path: The path to the file that needs the hash comment.
    """
    # Construct the expected hash comment line.
    expected_comment = f"# Hash: {file_hash}"
    try:
        # Open the file for reading using Kodi's xbmcvfs.
        f = xbmcvfs.File(file_path, 'r')
        content = f.read()
        f.close()

        # Split the file content into lines.
        lines = content.split('\n')
        
        # If the file already has the hash comment, log and exit.
        if any(line.strip() == expected_comment for line in lines):
            VSlog(f"Hash comment is already present in {file_path}")
            return

        # Detect the line ending used in the file. Default to '\n'.
        line_ending = '\n'
        if content:
            if '\r\n' in content:
                line_ending = '\r\n'
            elif '\n' in content:
                line_ending = '\n'
            elif '\r' in content:
                line_ending = '\r'

        # Determine the proper insertion index by skipping initial blank or comment lines.
        insertion_index = 0
        for line in lines:
            stripped_line = line.strip()
            if stripped_line == "" or stripped_line.startswith("#"):
                insertion_index += 1
            else:
                break

        # Create the new comment line including the detected line ending.
        comment_line = f"{expected_comment}{line_ending}"
        # Insert the comment at the computed index.
        lines.insert(insertion_index, comment_line)

        # Join the lines back together into a single string for writing.
        new_content = '\n'.join(lines)

        # Open the file for writing using xbmcvfs and save the updated content.
        f = xbmcvfs.File(file_path, 'w')
        success = f.write(new_content)
        f.close()

        # Log the outcome of the write operation.
        if success:
            VSlog(f"Hash comment inserted in: {file_path}")
        else:
            VSlog(f"Failed to write to {file_path}")
    except Exception as e:
        # Log and re-raise any exceptions that occur.
        VSlog(f"Error inserting hash comment in {file_path}: {e}")
        raise


def compute_file_hash(file_path: str) -> Optional[str]:
    """
    Computes the SHA-256 hash of the file located at file_path.
    
    :param file_path: The path of the file to hash.
    :return: The computed hash as a hexadecimal string or None if an error occurs.
    """
    VSlog(f"Starting hash computation for file: {file_path}")
    try:
        # Initialize a new SHA-256 hash object.
        sha256 = hashlib.sha256()

        # Open the file in binary mode using xbmcvfs.
        with xbmcvfs.File(file_path, 'rb') as f:
            while True:
                # Read the file in 4KB chunks.
                chunk = f.read(4096)
                if not chunk:
                    break
                # Kodi's xbmcvfs.File might return a Unicode string even in binary mode.
                # If that happens, encode the chunk to bytes.
                if isinstance(chunk, str):
                    chunk = chunk.encode('utf-8')
                sha256.update(chunk)

        # Convert the hash to a hexadecimal string.
        hash_result = sha256.hexdigest()
        VSlog(f"Hash computed successfully for file {file_path}: {hash_result}")
        return hash_result
    except Exception as e:
        # Log the error and return None if hashing fails.
        VSlog(f"Failed to compute hash for file {file_path}. Error: {e}")
        return None


def file_has_hash(file_path: str, expected_hash: str) -> bool:
    """
    Check if the file contains a comment with the expected hash anywhere in its content.
    
    :param file_path: The path to the file.
    :param expected_hash: The hash value to search for in the file's comments.
    :return: True if the expected hash is found in a comment; False otherwise.
    """
    try:
        # Open the file in binary mode.
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read()
            # If content is in bytes, decode it to a string.
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='ignore')
        # Split content into lines and check each line for the hash comment.
        for line in content.splitlines():
            stripped_line = line.strip()
            if stripped_line.startswith('#') and f'Hash: {expected_hash}' in stripped_line:
                VSlog(f"[INFO] File {file_path} contains hash: {expected_hash}")
                return True
        return False
        VSlog(f"[INFO] File {file_path} don't contains hash: {expected_hash}")
    except Exception as e:
        # Log an error if the file could not be read or processed.
        VSlog(f"[ERROR] Failed to check hash in {file_path}: {e}")
        return False


def download_file(url: str, dest_path: str, retries: int = 3, delay: int = 5) -> bool:
    """
    Download a file from a given URL and save it locally.
    This function uses retry logic and also checks whether the file is already up to date.
    
    :param url: The URL of the file to download.
    :param dest_path: The local destination path to save the file.
    :param retries: Number of retry attempts in case of failure.
    :param delay: Delay (in seconds) between retry attempts.
    :return: True if the file was successfully downloaded; False otherwise.
    """
    for attempt in range(1, retries + 1):
        try:
            # If the destination file already exists, compare its size to the remote file.
            if xbmcvfs.exists(dest_path):
                # Create a HEAD request to get the remote file's Content-Length.
                req = urllib.request.Request(url, method='HEAD')
                with urllib.request.urlopen(req) as response:
                    remote_size = response.getheader('Content-Length')
                # Get the local file size.
                with xbmcvfs.File(dest_path, 'rb') as f:
                    local_size = f.size()
                # If sizes match, assume the file is up-to-date and skip the download.
                if remote_size and int(remote_size) == local_size:
                    VSlog("[INFO] File already downloaded and up to date. Skipping download.")
                    return False

            # Open the URL and read the file content.
            with urllib.request.urlopen(url) as response:
                data = response.read()
            # Write the downloaded data to the destination file in binary mode.
            with xbmcvfs.File(dest_path, 'wb') as f:
                f.write(data)
            VSlog(f"[INFO] Successfully downloaded {url} to {dest_path}")
            return True
        except Exception as e:
            # Log a warning if this download attempt fails.
            VSlog(f"[WARNING] Download attempt {attempt} failed: {e}")
            time.sleep(delay)
    # Log an error if all retry attempts fail.
    VSlog(f"[ERROR] Failed to download {url} after {retries} attempts.")
    return False


def update_by_vstream(file_path: str) -> bool:
    """
    Checks whether the downloaded update file is marked for vstream usage.
    This is determined by looking for a marker comment in the file.
    
    :param file_path: The path to the update file.
    :return: True if the marker (e.g., "# update by vstream") is found; False otherwise.
    """
    # Compile a regular expression to look for the marker comment (case-insensitive).
    marker_regex = re.compile(r'#\s*update\s+by\s+vstream', re.IGNORECASE)
    
    try:
        # Open the file in binary mode.
        with xbmcvfs.File(file_path, 'rb') as f:
            content = f.read()
            # If content is in bytes, decode it to a string.
            if isinstance(content, bytes):
                content = content.decode('utf-8', errors='ignore')
        # Check each line to see if it matches the marker regex.
        for line in content.splitlines():
            if marker_regex.search(line):
                return True
        return False
    except Exception as e:
        # Log any error encountered while reading the file.
        VSlog(f"[ERROR] Failed to read file {file_path} for update check: {e}")
        return False


def perform_vstream_update(new_update_file: str, installed_update_file: str, is_vstream_update: bool) -> None:
    """
    Copies the new update file to the appropriate installed location.
    If the update is not for vstream, additional actions (like module reload and method execution) are performed.
    
    :param new_update_file: The path to the downloaded update file.
    :param installed_update_file: The target path where the update file should be installed.
    :param is_vstream_update: A flag indicating if this is a vstream update.
    """
    VSlog(f'[INFO] vstream_update called at {time.strftime("%Y-%m-%d %H:%M:%S")}')
    try:
        if is_vstream_update:
            VSlog("[INFO] update.py marked for vstream usage.")
            # Copy the new update file to the vstream target location.
            success = xbmcvfs.copy(new_update_file, installed_update_file)
            if not success:
                VSlog(f"[ERROR] Failed to copy {new_update_file} to {installed_update_file}")
                return
            VSlog("[INFO] update.py copied successfully.")
        else:
            VSlog("[INFO] update.py marked for vstreamupdate usage.")
            # Copy the new update file to the src target location.
            success = xbmcvfs.copy(new_update_file, installed_update_file)
            if not success:
                VSlog(f"[ERROR] Failed to copy {new_update_file} to {installed_update_file}")
                return
            VSlog(f"[INFO] Copied new update.py from {new_update_file} to {installed_update_file}")
            
            # Reload the update module to apply new changes.
            from importlib import reload
            from resources.lib import update
            reload(update)
            
            # Create an instance of the update class and execute its update method.
            from resources.lib.update import cUpdate
            update_instance = cUpdate()
            update_instance.getUpdateSetting()
            VSlog("[INFO] Executed cUpdate().getUpdateSetting() successfully.")
            
        # Compute the hash of the new update file.
        new_hash = compute_file_hash(new_update_file)
        if new_hash:
            # Insert the computed hash as a comment into the installed update file.
            insert_hash_as_comment(new_hash, installed_update_file)
    except Exception as e:
        VSlog(f"[ERROR] vstream update failed: {e}")


def execute_update_setting(download_update_file: str, vstream_update_file: str, src_update_file: str) -> None:
    """
    Determines which update target to use (vstream or src) based on the downloaded update file.
    Then it executes the appropriate update routine.
    
    :param download_update_file: The path to the newly downloaded update file.
    :param vstream_update_file: The target path for vstream usage.
    :param src_update_file: The target path for src usage.
    """
    try:
        # Check whether the downloaded update file is marked for vstream usage.
        is_vstream_update = update_by_vstream(download_update_file)
        if is_vstream_update:
            VSlog("[INFO] New update file is marked for vstream; using vstream_update_file as target.")
            perform_vstream_update(download_update_file, vstream_update_file, is_vstream_update)
        else:
            VSlog("[INFO] New update file is not marked for vstream; using src_update_file as target.")
            perform_vstream_update(download_update_file, src_update_file, is_vstream_update)
    except Exception as e:
        VSlog(f"[ERROR] Failed to execute update function: {e}")


def is_installed(new_file: str, flag_file: str) -> bool:
    """
    Determines whether the installed update file already contains the hash of the new update file.
    This helps prevent re-applying the same update.
    
    :param new_file: The path to the newly downloaded update file.
    :param flag_file: The path to the installed update file to check for the hash comment.
    :return: True if the installed file includes the hash; False otherwise.
    """
    new_hash = compute_file_hash(new_file)
    if new_hash is None:
        return False
    return file_has_hash(flag_file, new_hash)


def periodic_update(download_update_file: str, vstream_update_file: str, src_update_file: str, interval: int) -> None:
    """
    Periodically checks for updates and applies them if necessary.
    This function runs in a continuous loop until Kodi sends an abort signal.
    
    :param download_update_file: The path to the downloaded update file.
    :param vstream_update_file: The target update file path for vstream usage.
    :param src_update_file: The target update file path for src usage.
    :param interval: Time interval (in seconds) between update checks.
    """
    # Create a monitor object to listen for Kodi abort requests.
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        # Check if the installed update file already has the correct hash.
        if not is_installed(download_update_file, vstream_update_file):
            try:
                execute_update_setting(download_update_file, vstream_update_file, src_update_file)
            except Exception as e:
                VSlog(f"[ERROR] Periodic update check failed: {e}")
        # Wait for the specified interval or until an abort is requested.
        if monitor.waitForAbort(interval):
            break
    VSlog("[INFO] Update monitor thread terminated.")


# ---------------------------
# Define file paths and URLs
# ---------------------------

# Define the base path for the service.vstreamupdate addon using VSPath.
vstreamupdate_path = VSPath('special://home/addons/service.vstreamupdate/').replace('\\', '/')

# Define the path to the installed update file for src usage.
src_update_file = os.path.join(vstreamupdate_path, 'resources', 'lib', 'update.py').replace('\\', '/')

# Define the path where the new update file will be downloaded.
download_update_file = os.path.join(vstreamupdate_path, "update.py").replace('\\', '/')

# Define the path to the installed update file for vstream usage.
vstream_update_file = VSPath('special://home/addons/plugin.video.vstream/resources/lib/update.py').replace('\\', '/')

# URL of the new update file to be downloaded.
update_url = "https://raw.githubusercontent.com/Ayuzerak/vupdate/refs/heads/main/update.py"


# -------------------------------------------
# Download and apply the update if necessary
# -------------------------------------------

# Attempt to download the update file.
if download_file(update_url, download_update_file):
    VSlog(f"[INFO] File saved successfully to {download_update_file}")
    # Execute the update settings based on the downloaded file.
    execute_update_setting(download_update_file, vstream_update_file, src_update_file)


# ------------------------------------------------
# Start a background thread for periodic updates
# ------------------------------------------------

# Create and start a daemon thread that periodically checks for updates.
periodic_thread = threading.Thread(
    target=periodic_update,
    args=(download_update_file, vstream_update_file, src_update_file, 60),  # Check every 60 seconds
    daemon=True
)

periodic_thread.start()
