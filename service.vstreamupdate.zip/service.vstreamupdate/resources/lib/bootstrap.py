import re
from resources.lib.logger import VSPath, VSlog

class Bootstrap:
    def __init__(self):
        VSlog("Bootstrap::__init__ called.")

    def init(self):
        VSlog("Bootstrap::init called.")
        addon_xml_path = VSPath("special://home/addons/plugin.video.vstream/addon.xml").replace('\\', '/')
        self.insert_regex_import_line(addon_xml_path)

    def insert_regex_import_line(self, addon_xml_path):
        """
        Ensures that addon.xml contains the line:
            <import addon="script.module.regex"/>
        If missing, it is inserted before the
            <import addon="script.module.dnspython" optional="true"/>
        line (after fixing its indentation) or before the closing </requires> tag if not found.
        """
        VSlog("Bootstrap::insert_regex_import_line() called.")

        try:
            with open(addon_xml_path, 'r', encoding='utf-8', errors='replace') as file:
                content = file.read()

            # If the regex import line is already present, do nothing.
            if re.search(r'<import\s+addon="script\.module\.regex"', content):
                VSlog("Regex import line already exists in addon.xml.")
                return

            # Define the desired indent for all <import> lines (newline plus 8 spaces).
            default_indent = "\n        "

            new_content = content  # fallback if neither dnspython nor </requires> is found

            # Look for the dnspython import line.
            # We include the preceding newline (and any whitespace) in group(1)
            dnspython_match = re.search(r'(\n[ \t]*)(<import\s+addon="script\.module\.dnspython".*?>)', content)
            if dnspython_match:
                # Force dnspython to have the default indent.
                dnspython_line = dnspython_match.group(2).lstrip()  # remove any existing whitespace
                corrected_dnspython_line = default_indent + dnspython_line

                # Create the regex import line using the same default indent.
                regex_import_line = default_indent + '<import addon="script.module.regex"/>'

                # Build a new block: first the regex line, then the (corrected) dnspython line.
                new_block = regex_import_line + corrected_dnspython_line

                # Replace the dnspython block (indentation + line) with our new block.
                new_content = content[:dnspython_match.start()] + new_block + content[dnspython_match.end():]

            else:
                # If dnspython wasn't found, try to insert before the closing </requires> tag.
                requires_match = re.search(r'(\n[ \t]*)(</requires>)', content)
                if requires_match:
                    regex_import_line = default_indent + '<import addon="script.module.regex"/>'
                    new_block = regex_import_line + requires_match.group(1) + requires_match.group(2)
                    new_content = content[:requires_match.start()] + new_block + content[requires_match.end():]
                else:
                    # Fallback: append at the end of the file.
                    new_content = content.rstrip() + default_indent + '<import addon="script.module.regex"/>\n'

            # Write the modified content back to the file.
            with open(addon_xml_path, 'w', encoding='utf-8') as file:
                file.write(new_content)

            VSlog("Successfully inserted regex import line with correct indentation.")

        except Exception as e:
            VSlog(f"Error modifying addon.xml: {e}")
